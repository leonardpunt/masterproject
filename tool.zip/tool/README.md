This tool detects undoing style in CSS code and is able to apply refactoring
opportunities to eliminate a subset of these instances of undoing style, while
preserving the semantics of the web application.

It is available under the [MIT license](https://opensource.org/licenses/MIT).

## Prerequisites
- [Firefox](https://www.mozilla.org/firefox/new/)
- [Firebug](https://addons.mozilla.org/nl/firefox/addon/firebug/)
- [npm](https://www.npmjs.com/)
- [This tool](https://leonardpunt.github.io/masterproject/)

## Setting it up
- Unzip the downloaded tool
- Install dependencies by running `npm install`
- Build the tool by running `grunt`
- Two build artifacts can be found in the folder `dist`:
  - `tool.min.js`: the tool, with minified source code
  - `tool.js`: the tool, without minified source code; useful for debugging

## Running it
- Open Firefox
- Browse to the webpage you'd like to analyse
- Open Firebug
- Paste contents of `tool.min.js` in Firebug's Command Line
- Click `Run` button
- Now these two entry points are available in Firebug's Command Line:
  - `detect()` - Detects undoing style in CSS. Results of the analysis are saved
    to a text file. After the analysis is completed, the user is prompted to
    download the results (`detectionsX.txt`).
  - `detectAndRefactor()` - Detects undoing style in CSS and applies refactoring
    opportunities. Results of the analysis are saved to a text file. Refactoring
    opportunities are applied dynamically. After the analysis and refactoring is
    completed, the user is prompted to download the results. The results
    comprise:
    - Detected undoing style (`detectionsX.txt`)
    - Detected semantic changes (`errors.txt`)
    - Refactored stylesheets (`<name of original stylesheet>`)

## Examples
The tool can be analyse a single state of a web application, as well as multiple
states (or pages) of a web application. In this section we'll demo both cases.
Furthermore, we'll explain the output format.

### Single state
- Open the web application in the desired state. E.g.
  [this web application](https://leonardpunt.github.io/masterproject/), which
  has only one state.
- Run tool as described in section "Running it".

### Multiple states
- Capture the multiple states of the web application (e.g. by opening the web
  application in a desired state and saving it).
- Create a new HTML document, using this template:

```
<!DOCTYPE html>
<html>
<head>
  <title>[site name]</title>
</head>
<body>
  <iframe src="[some-state.html]" width="90%" height="300px"></iframe>
  <iframe src="[another-state.html]" width="90%" height="300px"></iframe>
</body>
</html>
```

- Open this new HTML document.
- Run tool as described in section "Running it", only now pass the value `true`
  to both entry points. I.e. `detect(true)` and/or `detectAndRefactor(true)`.

### Output
Example of output:
```
-- SMELL: 1 --
Smell: A-B(1)-A on margin-top
- initial: 0px (p)
- enclosed: 5px (#some-id)
- reset: 0px (#some-id.some-class)
- refactorable: true
- nodes: <p id="some-id" class="some-class">
```
The first line denotes the number of the undoing style pattern. The next line
describes which pattern is found and on which CSS property, in this example we
found the A-B(1)-A pattern on the CSS property `margin-top`.

The next lines show the CSS selector which sets the style initially, the CSS
selector(s) that are enclosed and the CSS selector that resets the style.

The last but one line shows if the pattern can be refactored. The last line
shows the nodes that applied to the detected pattern.

## Quality
There are unit tests. Furthermore, all code should pass our JSHint rules. Verify
this by running `grunt test`.
