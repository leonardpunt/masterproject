/*global CSSParserExtension, UndoingStyle, Utils, RefactorUndoingStyle, StyleSheets, CSSStyleRule, Downloader*/

var nrOfCSSRulesBefore, nrOfCSSRulesAfter = 0;

function detect(isMultiple, frameIndex, allStyleSheets) {
  var t0 = new Date();
  frameIndex = frameIndex ? frameIndex : 0;
  var _document = isMultiple ? frames[frameIndex].document : document;
  var _window = isMultiple ? frames[frameIndex].window : window;
  var startNode = _document.body;
  // Let each iframe use the same style sheets, otherwise the previous refactorings are not visible
  allStyleSheets = allStyleSheets ? allStyleSheets : StyleSheets.getAllStyleSheets(isMultiple);

  if (isMultiple) {
    console.log("Checking frame: ", frameIndex);
    setPrototypeFunctions();
  }

  // Detect
  var smells = detectSmells(startNode, _document, allStyleSheets, _window, isMultiple);
  persistSmells(smells, frameIndex);

  var nrOfSmells = smells.reduce(function(acc, arr) { return acc + arr.length; }, 0);
  console.log("Found", nrOfSmells, "smells");
  console.log("Took", new Date().getTime() - t0.getTime(), "milliseconds");

  if (isMultiple && frameIndex < frames.length - 1) {
    detect(isMultiple, frameIndex + 1, allStyleSheets);
  }
}

function detectAndRefactor(isMultiple, frameIndex, allStyleSheets) {
  var t0 = new Date();
  frameIndex = frameIndex ? frameIndex : 0;
  var _document = isMultiple ? frames[frameIndex].document : document;
  var _window = isMultiple ? frames[frameIndex].window : window;
  var startNode = _document.body;
  var computedStylesBefore = getComputedStylesBefore(isMultiple, startNode);
  // Let each iframe use the same style sheets, otherwise the previous refactorings are not visible
  allStyleSheets = allStyleSheets ? allStyleSheets : StyleSheets.getAllStyleSheets(isMultiple);

  if (isMultiple) {
    console.log("Checking frame: ", frameIndex);
    setPrototypeFunctions();
  }

  // Detect
  var smells = detectSmells(startNode, _document, allStyleSheets, _window, isMultiple);

  // Refactor
  smells.forEach(function(enclosedRulesGroup) {
    var updates = RefactorUndoingStyle.refactor(enclosedRulesGroup, isMultiple);
    // Apply updates of last refactoring to all rules
    smells = RefactorUndoingStyle.updateReferences(smells, updates);
  });

  // Check semantics
  var errors = checkSemantics(computedStylesBefore, isMultiple);
  nrOfCSSRulesAfter = getNumberOfCSSRules(_document, allStyleSheets);

  // Persist info
  persistSmells(smells, frameIndex);
  persistSemanticsErrors(errors, frameIndex);

  var nrOfSmells = smells.reduce(function(acc, arr) { return acc + arr.length; }, 0);
  console.log("Found", nrOfSmells, "smells");
  console.log("Took", new Date().getTime() - t0.getTime(), "milliseconds");

  if (isMultiple && frameIndex < frames.length - 1) {
    detectAndRefactor(isMultiple, frameIndex + 1, allStyleSheets);
  } else {
    persistStyleSheets(allStyleSheets);
    persistHTMLDocument(isMultiple);
  }
}

function setPrototypeFunctions() {
  for (var i = 0; i < frames.length; i++) {
    frames[i].CSSStyleRule.prototype.insertAfter = CSSStyleRule.prototype.insertAfter;
    frames[i].CSSStyleRule.prototype.delete = CSSStyleRule.prototype.delete;
    frames[i].CSSStyleRule.prototype.removeSelector = CSSStyleRule.prototype.removeSelector;
  }
}

function getComputedStylesBefore(isMultiple, startNode) {
  var computedStylesBefore;

  if (isMultiple) {
    computedStylesBefore = [];
    for (var i = 0; i < frames.length; i++) {
      var startNodeForIFrame = frames[i].document.body;
      computedStylesBefore.push(CSSParserExtension.getAllComputedStyles(startNodeForIFrame));
    }
  } else {
    computedStylesBefore = CSSParserExtension.getAllComputedStyles(startNode);
  }

  return computedStylesBefore;
}

function detectSmells(startNode, _document, allStyleSheets, _window, isMultiple) {
  // Prepare
  var nodesWithRules = {};
  addGuidToNodes(startNode, nodesWithRules);
  var styleSheets = StyleSheets.getStyleSheetsForDocument(_document, allStyleSheets);
  var cssRules = CSSParserExtension.getRules(styleSheets);
  nrOfCSSRulesBefore = cssRules.length;
  CSSParserExtension.populateNodesWithRules(_document, cssRules, nodesWithRules);

  // Detect
  var nodesWithSmell = check(startNode, nodesWithRules, cssRules, styleSheets, _window, isMultiple);
  var groupedNodesWithSmell = groupByNode(nodesWithSmell);
  var groupedEnclosedRules = groupByEnclosedRule(groupedNodesWithSmell);
  sortByReset(groupedEnclosedRules);
  sortByEnclosed(groupedEnclosedRules);

  return groupedEnclosedRules;
}

function addGuidToNodes(node, nodesWithRules) {
  node.guid = Utils.guid();
  nodesWithRules[node.guid] = [];
  Utils.forEach(node.children, function(child) {
    addGuidToNodes(child, nodesWithRules);
  });
}

function check(node, nodesWithRules, cssRules, styleSheets, _window, isMultiple) {
  var nodeSmells = getSmells(node, nodesWithRules, cssRules, styleSheets, _window, isMultiple);
  var childrenSmells = Utils.flatMap(node.children, function(child) {
    return check(child, nodesWithRules, cssRules, styleSheets, _window, isMultiple);
  });
  return nodeSmells.concat(childrenSmells);
}

function getSmells(node, nodesWithRules, cssRules, styleSheets, _window, isMultiple) {
  var definedCSSRules = CSSParserExtension.getDefinedRules(node, nodesWithRules);
  var implicitStyles = CSSParserExtension.getImplicitStyles(node, definedCSSRules, cssRules, _window);
  var smells = UndoingStyle.filterUndoingStyle(definedCSSRules, implicitStyles, styleSheets, isMultiple);
  return smells.map(function(smell) {
    return { node: node, smell: smell };
  });
}

function getNumberOfCSSRules(_document, allStyleSheets) {
  var styleSheets = StyleSheets.getStyleSheetsForDocument(_document, allStyleSheets);
  return CSSParserExtension.getRules(styleSheets).length;
}

function printSmell(smell, nodes) {
  console.log("Smell: A-B(" + smell.enclosed.length + ")-A on", smell.initial.declaration.property);
  console.log("- initial:", smell.initial.declaration.value, "(", smell.initial.ruleWrapper ? smell.initial.ruleWrapper.rule : "implicit", ")");
  smell.enclosed.slice().reverse().forEach(function(enclosed) {
    console.log("- enclosed:", enclosed.declaration.value, "(", enclosed.ruleWrapper.rule, ")");
  });
  console.log("- reset:", smell.reset.declaration.value, "(", smell.reset.ruleWrapper.rule, ")");
  console.log("- nodes:", nodes);
}

function smellToString(smell, nodes) {
  var str = "Smell: A-B(" + smell.enclosed.length + ")-A on " + smell.initial.declaration.property + "\n";
  str += "- initial: " + smell.initial.declaration.value + " (" + (smell.initial.ruleWrapper ? smell.initial.ruleWrapper.selectorText + "|" + smell.initial.ruleWrapper.rule.selectorText : "implicit") + ")\n";
  smell.enclosed.slice().reverse().forEach(function(enclosed) {
    str += "- enclosed: " + enclosed.declaration.value + " (" + enclosed.ruleWrapper.selectorText + "|" + enclosed.ruleWrapper.rule.selectorText + ")\n";
  });
  str += "- reset: " + smell.reset.declaration.value + " (" + smell.reset.ruleWrapper.selectorText + "|" + smell.reset.ruleWrapper.rule.selectorText + ")\n";
  str += "- refactorable: " + smell.isRefactorable + "\n";
  str += "- nodes: " + nodes.map(function(node) { return nodeToString(node); }) + "\n";
  return str;
}

function nodeToString(node) {
  var tag = "<" + node.localName;
  Utils.forEach(node.attributes, function(attribute) {
    tag += " " + attribute.name + "=\"" + attribute.value + "\"";
  });
  tag += ">";
  return tag;
}

/* Figure out which nodes apply to a smell (needed since we check smells per
   node, so this grouping checks if we found a smell that is prevelent to
   multiple nodes)

   I.e. the same nodes are grouped together
   [{node, smell}, {node, smell}] -> [{[node], smell}] */
function groupByNode(nodesWithSmell) {
  return getValues(nodesWithSmell.reduce(function(accum, nodeWithSmell) {
    var node = nodeWithSmell.node;
    var smell = nodeWithSmell.smell;
    if (smell) {
      var key = JSON.stringify(smell);
      if (key in accum) {
        accum[key].nodes.push(node);
      } else {
        accum[key] = { nodes: [node], smell: smell };
      }
    }
    return accum;
  }, {}));
}

/* Figure out if a rule is undone multiple times (needed since a rule can be
   undone by multiple styles, e.g. A-B-A and C-B-C)

   I.e. the same enclosed rules are grouped together
   [{[node], smell}, {[node], smell}] -> [[{[node], smell}, {[node], smell}]] */
function groupByEnclosedRule(groupedNodesWithSmell) {
  return getValues(groupedNodesWithSmell.reduce(function(accum, nodesWithSmellGroup) {
    if (nodesWithSmellGroup) {
      var key = JSON.stringify(nodesWithSmellGroup.smell.enclosed);
      if (key in accum) {
        accum[key].push(nodesWithSmellGroup);
      } else {
        accum[key] = [nodesWithSmellGroup];
      }
    }
    return accum;
  }, {}));
}

function getValues(map) {
  var arr = [];
  for (var key in map) {
    arr.push(map[key]);
  }
  return arr;
}

function sortByReset(groupedEnclosedRules) {
  groupedEnclosedRules.forEach(function(enclosedRulesGroup) {
    enclosedRulesGroup.sort(function(nodesWithSmell1, nodesWithSmell2) {
      var specificity1 = nodesWithSmell1.smell.reset.ruleWrapper.specificity;
      var specificity2 = nodesWithSmell2.smell.reset.ruleWrapper.specificity;
      return Utils.compareSpecificity(specificity2, specificity1);
    });
  });
}

function sortByEnclosed(groupedEnclosedRules) {
  groupedEnclosedRules.sort(function(enclosedRulesGroup1, enclosedRulesGroup2) {
    var enclosed1 = enclosedRulesGroup1[0].smell.enclosed[0];
    var enclosed2 = enclosedRulesGroup2[0].smell.enclosed[0];
    var specificity1 = enclosed1 ? enclosed1.ruleWrapper.specificity : [0,0,0,0];
    var specificity2 = enclosed2 ? enclosed2.ruleWrapper.specificity : [0,0,0,0];
    return Utils.compareSpecificity(specificity2, specificity1);
  });
}

function checkSemantics(computedStylesBefore, isMultiple) {
  var errors = "";
  if (isMultiple) {
    computedStylesBefore.forEach(function(computedStylesForIFrame, i) {
      errors += compareSemantics(computedStylesForIFrame, 0, frames[i].document.body, frames[i].window, "").errors;
    });
  } else {
    errors = compareSemantics(computedStylesBefore, 0, document.body, window, "").errors;
  }
  return errors;
}

function compareSemantics(computedStylesBefore, index, node, _window, errors) {
  var before = computedStylesBefore[index];
  var after = CSSParserExtension.getComputedStyle(node, _window);
  if (!isEqualComputedStyles(before, after)) {
    errors += "Found error at node " + nodeToString(node) + "\n";
    Object.keys(before).forEach(function(key) {
      if (before[key] !== after[key]) {
        errors += "Key: " + key + ", before: " + before[key] + ", after: " + after[key] + "\n";
      }
    });
    errors += "\n";
  }
  index++;

  Utils.forEach(node.children, function(child) {
    var result = compareSemantics(computedStylesBefore, index, child, _window, errors);
    index = result.index;
    errors = result.errors;
  });

  return { index: index, errors: errors };
}

function isEqualComputedStyles(left, right) {
  left = JSON.stringify(left);
  right = JSON.stringify(right);
  return left === right;
}

function persistStyleSheets(styleSheets) {
  styleSheets.forEach(function(styleSheet) {
    try {
      var name = styleSheet.href ? styleSheet.href.split("/").pop() : "internal";
      var cssText = Utils.reduce(styleSheet.cssRules, function(accum, cssRule) {
        return accum + cssRule.cssText + "\n";
      }, "");
      Downloader.download(cssText, name, "text/plain");
    } catch (e) {
      console.log("Error while reading: " + styleSheet.href + ". Message: " + e.message);
    }
  });
}

function persistHTMLDocument(isMultiple) {
  var name = window.location.pathname.split("/").pop();
  var html = document.documentElement.outerHTML;
  html = html.replace(/<a\sdownload.*<\/body>/, "</body>");
  Downloader.download(html, name, "text/plain");

  if (isMultiple) {
    Utils.forEach(frames, function(frame) {
      var name = frame.window.location.pathname.split("/").pop();
      var html = frame.document.documentElement.outerHTML;
      Downloader.download(html, name, "text/plain");
    });
  }
}

function persistSmells(groupedEnclosedRules, frameIndex) {
  var x = 0;
  var smells = "";

  groupedEnclosedRules.forEach(function(enclosedRulesGroup) {
    enclosedRulesGroup.forEach(function(nodesWithSmell) {
      var nodes = nodesWithSmell.nodes;
      var smell = nodesWithSmell.smell;
      x++;

      smells += "-- SMELL: " + (x) + " --\n";
      smells += smellToString(smell, nodes);
    });
  });

  var nrOfSmells = groupedEnclosedRules.reduce(function(acc, arr) { return acc + arr.length; }, 0);
  smells += "\nFound " + nrOfSmells + " smells";
  smells += "\n# CSS rules, before: " + nrOfCSSRulesBefore + ", after: " + nrOfCSSRulesAfter;

  Downloader.download(smells, "detections" + frameIndex + ".txt", "text/plain");
}

function persistSemanticsErrors(errors, frameIndex) {
  Downloader.download(errors, "errors" + frameIndex + ".txt", "text/plain");
}
