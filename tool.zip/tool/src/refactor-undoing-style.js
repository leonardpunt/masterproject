/*global CSSParserExtension, CSSSelectorParser, Utils, printSmell*/

var RefactorUndoingStyle = (function() {
  var refactor = function(enclosedRulesGroup, isMultiple) {
    var allUpdates = [];
    var originalId, property, newEnclosedRuleWrapper;

    enclosedRulesGroup.forEach(function(nodesWithSmell, i) {
      var smell = nodesWithSmell.smell;
      if (!smell.isRefactorable) {
        console.log("Smell not refactorable.");
        return;
      }
      if (smell.enclosed[0].ruleWrapper.rule.cssText === "" || smell.reset.ruleWrapper.rule.cssText === "") {
        console.log("Ignoring this undoing style, since it seems already been fixed by a previous refactoring.");
        return;
      }

      console.log("-- REFACTORING SMELL --");
      printSmell(enclosedRulesGroup[0].smell, enclosedRulesGroup[0].nodes);

      var updates = [];

      if (!_isInlineStyle(smell.enclosed[0])) {
        originalId = enclosedRulesGroup[0].smell.enclosed[0].ruleWrapper.id;
        property = enclosedRulesGroup[0].smell.enclosed[0].declaration.property;

        // Step 1: move the enclosed/overridden property to a new rule
        var newRule = _createRule(smell.enclosed[0]);
        var insertedRule = smell.enclosed[0].ruleWrapper.rule.insertAfter(newRule.cssText);
        var updatesStep1 = _removeProperty(smell.enclosed[0].ruleWrapper, smell.enclosed[0].declaration.property);
        smell.enclosed[0].ruleWrapper = updatesStep1[updatesStep1.length-1].newRuleWrapper;

        // Fix for if the enclosed rule and the reset rule are in the same grouped rule
        if (updatesStep1.length === 2) {
          if (updatesStep1[0].groupId === smell.reset.ruleWrapper.groupId) {
            smell.reset.ruleWrapper.rule = updatesStep1[0].newRule;
          }
        }
        updates = updates.concat(updatesStep1);

        // Step 2: add class of new rule to the correct DOM elements
        var nodes = _getNodes(smell.enclosed[0].ruleWrapper.rule.selectorText, isMultiple);
        var selectorText = smell.reset.ruleWrapper.selectorText;
        // Because of previous refactorings, the nodes to which this selector applies might have changed
        var otherNodes = _isInlineStyle(smell.reset) ? nodesWithSmell.nodes : _getNodes(selectorText, isMultiple);
        _addClasses(Utils.diff(nodes, otherNodes), newRule.className);

        // Clean up empty rule
        if (smell.enclosed[0].ruleWrapper.rule.style.length === 0) {
          smell.enclosed[0].ruleWrapper.rule.delete();
        }

        // Update reference for next undoing style
        newEnclosedRuleWrapper = {
          id: Utils.guid(),
          groupId: Utils.guid(),
          rule: insertedRule,
          selector: newRule.selector,
          selectorText: newRule.selectorText
        };
        if (enclosedRulesGroup[i+1]) {
          enclosedRulesGroup[i+1].smell.enclosed[0].ruleWrapper = newEnclosedRuleWrapper;
        }
      } else {
        // If enclosed rule is inline style, we can just remove the style property
        _removeInlineStyle(nodesWithSmell.nodes[0], smell.enclosed[0].declaration.property);
      }

      // Step 3: remove the property from style reset rule
      if (_isInlineStyle(smell.reset)) {
        _removeInlineStyle(nodesWithSmell.nodes[0], smell.reset.declaration.property);
      } else {
        var updatesStep3 = _removeProperty(smell.reset.ruleWrapper, smell.reset.declaration.property);
        smell.reset.ruleWrapper = updatesStep3[updatesStep3.length-1].newRuleWrapper;
        updates = updates.concat(updatesStep3);

        if (smell.reset.ruleWrapper.rule.style.length === 0) {
          smell.reset.ruleWrapper.rule.delete();
        }
      }

      updateReferences([enclosedRulesGroup], updates);
      allUpdates = allUpdates.concat(updates);
    });

    // Inform about the newly created class
    if (originalId) {
      allUpdates.push({ id: originalId, property: property, newRuleWrapper: newEnclosedRuleWrapper });
    }

    return allUpdates;
  };

  var _createRule = function(overriddenStyle) {
    var newSelector = _newSelector(overriddenStyle.ruleWrapper.selector);
    var declaration = overriddenStyle.declaration;
    var newDeclaration = declaration.property + ": " + declaration.value +
      (declaration.isImportant ? " !important;" : ";");
    return {
      className: newSelector.className,
      selector: newSelector.selector,
      selectorText: newSelector.selectorText,
      cssText: newSelector.selectorText + "{ " + newDeclaration + " }" };
  };

  var _newSelector = function(currentSelector) {
    var newClassName = "refactoring-" + Utils.guid();
    var newSelector = JSON.parse(JSON.stringify(currentSelector));
    var selectorUnit = getMostSpecificSelectorUnit(newSelector.rule);

    if (selectorUnit.classNames) {
      var classNames = _removeLastClassName(selectorUnit.classNames);
      classNames.push(newClassName);
      selectorUnit.classNames = classNames;
    } else if (selectorUnit.id) {
      selectorUnit.classNames = [newClassName];
    } else if (selectorUnit.tagName) {
      if (selectorUnit.tagName === "*" && newSelector.rule.rule) {
        var parentOfSelectorUnit = _getParentOfMostSpecificSelectorUnit(newSelector.rule);
        delete parentOfSelectorUnit.rule;
        return _newSelector(newSelector);
      }
      delete selectorUnit.tagName;
      selectorUnit.classNames = [newClassName];
    } else if (selectorUnit.attrs) {
      selectorUnit.classNames = [newClassName];
    }
    else {
      throw new Error("Assertion error. Cannot deal with this selector" + JSON.stringify(currentSelector));
    }

    return {
      className: newClassName,
      selector: newSelector,
      selectorText: CSSSelectorParser.render(newSelector)
    };
  };

  var getMostSpecificSelectorUnit = function(rule) {
    while (rule.rule) {
      rule = rule.rule;
    }
    return rule;
  };

  var _getParentOfMostSpecificSelectorUnit = function(rule) {
    while (rule.rule.rule) {
      rule = rule.rule;
    }
    return rule;
  };

  var _removeLastClassName = function(classNames) {
    return classNames.slice(0, classNames.length - 1);
  };

  /* This function removes a property from a rule.
     If the selector of the rule is not a grouping selector, the property will be simply removed.
     If the selector of the rule is a grouping selector, then:
     - The current selector will be removed from the grouped selector.
     - If there are multiple styles defined, the rule will be copied with as selector the current
       selector. The property that had to be removed will be removed from this new rule.*/
  var _removeProperty = function(ruleWrapper, property) {
    if (!_isGroupingSelector(ruleWrapper.rule.selectorText)) {
      ruleWrapper.rule.style.removeProperty(property);
      return [{ id: ruleWrapper.id, newRuleWrapper: ruleWrapper }];
    } else {
      // Create new rule, with only one selector and remove the property from this rule
      var cssText = ruleWrapper.selectorText + "{" + ruleWrapper.rule.style.cssText + "}";
      var newRule = ruleWrapper.rule.insertAfter(cssText);
      newRule.style.removeProperty(property);
      var newRuleWrapper = {
        id: Utils.guid(),
        groupId: Utils.guid(),
        rule: newRule,
        selector: ruleWrapper.selector,
        selectorText: ruleWrapper.selectorText
      };

      // Remove copied selector from original rule
      var updatedRule = ruleWrapper.rule.removeSelector(ruleWrapper.selectorText);

      // Return updates
      return [
        { groupId: ruleWrapper.groupId, newRule: updatedRule }, // For the other rules in this group, we only have to update the rule
        { id: ruleWrapper.id, newRuleWrapper: newRuleWrapper } // The order matters!
      ];
    }
  };

  var _isGroupingSelector = function(selector) {
    return selector.indexOf(",") !== -1;
  };

  var _getNodes = function(selectorText, isMultiple) {
    if (isMultiple) {
      var nodes = [];
      for (var i = 0; i < frames.length; i++) {
        nodes = nodes.concat(Utils.flatten(frames[i].document.querySelectorAll(selectorText)));
      }
      return nodes;
    } else {
      return document.querySelectorAll(selectorText);
    }
  };

  var _addClasses = function(nodes, className) {
    Utils.forEach(nodes, function(node) {
      node.classList.add(className);
    });
  };

  var _isInlineStyle = function(undoingStyle) {
    return undoingStyle.ruleWrapper.selectorText === CSSParserExtension.INLINE_SELECTOR;
  };

  var _removeInlineStyle = function(element, property) {
    element.style.removeProperty(property);

    if (element.style.length === 0) {
      element.getAttribute("style"); // Bugfix, see: http://stackoverflow.com/questions/7165359/removeattribute-doesnt-work-dom/7167553#7167553
      element.removeAttribute("style");
    }
  };

  /*
    1. In case of an addition (e.g. a property moved to a new rule):
      1.1 We check if there is any ruleWrapper with the same id and same property. These ruleWrappers are updated.
    2. In case of an removal (e.g. a property is removed from a rule):
      2.1 If the rule is a non-grouped rule, we de nothing. Updates are not needed, since we take care of already refactored rules in a later stage.
      2.2 If the rule is a grouped rule:
        2.2.1 We check if there are ruleWrappers with the same group id. The rule property of these ruleWrappers is updated (since it might be the case this rule was deleted and created again)
        2.2.2 We check if there are ruleWrappers with the same id. These ruleWrappers are updated, because they have been split off the grouped rule.

    Note that the order of the updates is important.
    If for example a rule in a grouped rule is refactored, we expect three updates in this order:
      - An update for the group, see 2.2.1
      - An update for the rule, see 2.2.2
      - An update for a newly added rule, see 1.1
    If the first and second update would swap, than the second update will override the first update, resulting in a wrong state.
  */
  var updateReferences = function(groupedEnclosedRules, updates) {
    return groupedEnclosedRules.map(function(enclosedRulesGroup) {
      return enclosedRulesGroup.map(function(nodesWithSmell) {
        if (nodesWithSmell.smell.enclosed[0]) {
          nodesWithSmell.smell.enclosed[0].ruleWrapper = _updateRuleWrapper(nodesWithSmell.smell.enclosed[0].declaration, nodesWithSmell.smell.enclosed[0].ruleWrapper, updates);
        }
        nodesWithSmell.smell.reset.ruleWrapper = _updateRuleWrapper(nodesWithSmell.smell.reset.declaration, nodesWithSmell.smell.reset.ruleWrapper, updates);
        return nodesWithSmell;
      });
    });
  };

  function _updateRuleWrapper(declaration, ruleWrapper, allUpdates) {
    var updates = allUpdates.filter(function(update) {
      return (!update.property || update.property === declaration.property) &&
        (update.id === ruleWrapper.id || update.groupId === ruleWrapper.groupId);
    });
    var lastUpdate = updates[updates.length - 1];

    if (lastUpdate) {
      if (lastUpdate.newRuleWrapper) { // Update to rule
        ruleWrapper = lastUpdate.newRuleWrapper;
      } else { // Update to group
        ruleWrapper.rule = lastUpdate.newRule;
      }
    }

    return ruleWrapper;
  }

  var api = {
    refactor: refactor,
    getMostSpecificSelectorUnit: getMostSpecificSelectorUnit,
    updateReferences: updateReferences
  };

  /* test-code */
  api._createRule = _createRule;
  api._newSelector = _newSelector;
  /* end-test-code */

  return api;

}());
