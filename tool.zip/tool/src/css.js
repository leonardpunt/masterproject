/*global Utils, CSSStyleRule, Specificity, CSSSelectorParser, CSSMediaQueryParser, CustomCSSStyleRule*/

var CSSParserExtension = (function() {

  var INLINE_SELECTOR = "_inline";

  var getRules = function(styleSheets) {
    return Utils.flatMap(styleSheets, function(styleSheet) {
      if (!_isDestinationMediumScreen(styleSheet.media.mediaText)) {
        console.log("Ignoring stylesheet " + styleSheet.href + " since it's media is not 'screen' or 'all'");
        return [];
      }

      /* Firefox throws security exception when requesting cssRules of
         stylesheet loaded from another origin. */
      try {
        return _mapRules(styleSheet.cssRules);
      } catch (e) {
        console.log("Error while reading: " + styleSheet.href + ". Message: " + e.message);
        return [];
      }
    });
  };

  var _isDestinationMediumScreen = function(mediaText) {
    if (mediaText === "") {
      return true; // since default media is 'screen'
    }

    var mediaQuery = CSSMediaQueryParser.parse(mediaText);

    return Utils.some(mediaQuery, function(mediumQuery) {
      if (mediumQuery.inverse) { // e.g. 'not screen'
        return mediumQuery.type !== "screen" && mediumQuery.type !== "all";
      } else { // e.g. 'screen'
        return mediumQuery.type === "screen" || mediumQuery.type === "all";
      }
    });
  };

  var _mapRules = function(cssRules) {
    return Utils.flatMap(cssRules, function(rule) {
      if ((rule instanceof CSSStyleRule || rule instanceof CustomCSSStyleRule) && !_isVML(rule)) {
        var selectors = _splitGroupingSelector(rule.selectorText);
        return _mapSelectors(selectors, rule);
      } else {
        /* Ignore: CSSUnknownRule, CSSCharsetRule, CSSImportRule, CSSMediaRule
           CSSFontFaceRule, CSSPageRule, CSSKeyframesRule, CSSKeyframeRule,
           CSSNamespaceRule, CSSCounterStyleRule, CSSSupportsRule,
           CSSDocumentRule, CSSFontFeatureValuesRule, CSSViewportRule,
           CSSRegionStyleRule, CSSGroupingRule,
           CSSConditionRule */
        console.log("Ignoring rule", rule);
        return [];
      }
    });
  };

  var _isVML = function(rule) {
    return rule.cssText.indexOf("v\\:") > -1;
  };

  var _splitGroupingSelector = function(selectorText) {
    var result = CSSSelectorParser.parse(selectorText);
    return result.selectors ? result.selectors : [result];
  };

  var _mapSelectors = function(selectors, rule) {
    var groupId = Utils.guid();
    return selectors.map(function(selector) {
      var selectorText = CSSSelectorParser.render(selector);
      var specificity = Specificity.calculate(selectorText)[0].specificity;
      return {
        id: Utils.guid(),
        groupId: groupId,
        rule: rule,
        selector: selector,
        selectorText: selectorText,
        specificity: specificity,
        declarations: _getDeclarations(rule.style)
      };
    });
  };

  var populateNodesWithRules = function(_document, rules, nodesWithRules) {
    rules.forEach(function(rule) {
      var nodes = _document.querySelectorAll(rule.selectorText);
      Utils.forEach(nodes, function(node) {
        if (node.guid) {
          nodesWithRules[node.guid].push(rule);
        }
      });
    });
  };

  var getDefinedRules = function(node, nodesWithRules) {
    var inlineRule = _getInlineStyle(node);
    var styleSheetRules = nodesWithRules[node.guid];
    return styleSheetRules.concat(inlineRule);
  };

  var _getInlineStyle = function(node) {
    return node.style.length > 0 ? [{
      id: Utils.guid(),
      groupId: Utils.guid(),
      rule: {
        selectorText: INLINE_SELECTOR
      },
      selector: {
        rule: {}
      },
      selectorText: INLINE_SELECTOR,
      specificity: [1,0,0,0],
      declarations: _getDeclarations(node.style)
    }] : [];
  };

  var _getDeclarations = function(style) {
    var declarations = {};
    for (var i = 0; i < style.length; i++) {
      var property = style[i];
      declarations[property] = {
        value: style.getPropertyValue(property),
        isImportant: style.getPropertyPriority(property) === 'important'
      };
    }
    return declarations;
  };

  /* The implicit style is:
      - the default style (i.e. user-agent style), if defined. Otherwise:
        - for inheriting properties: the inherited style, i.e. the computed
          style of the parent element.
        - for non-inheriting properties: the initial style (i.e. W3C spec).

     We get the implicit style by requesting the computed style of an element,
     after disabling all author styles (external, internal and inline) that
     apply to this node.
     This is the only correct way, since the function
     'window.getComputedStyle()' will return the default style if it is defined,
     if not it returns the inherited style for inheriting properties and the
     initial style for non-inheriting properties.

     Note that using window.getDefaultComputedStyle() won't work correctly,
     because it disables all styles, not only the styles that apply to this
     node. Therefore it always returns the default or initial style, never the
     inherited style.

     Also note that disabling the style sheets won't work. Since the style
     sheets might contain rules that apply to the parent element. So we have to
     delete the rules that apply to a node temporarily.*/
  var getImplicitStyles = function(node, definedCSSRules, cssRules, _window) {
    // Disable inline styles
    var inlineStyle = node.style.cssText;
    if (inlineStyle !== "") {
      node.removeAttribute("style");
    }
    // Disable external and internal styles
    definedCSSRules.forEach(function(rule) {
      if (rule.selectorText !== CSSParserExtension.INLINE_SELECTOR && _isFirstOfGroupedRuleForDeletion(rule)) {
        rule.index = Utils.indexOf(rule.rule.parentStyleSheet.cssRules, rule.rule);
        rule.cssText = rule.rule.cssText;
        rule.parentStyleSheet = rule.rule.parentStyleSheet;
        rule.parentStyleSheet.deleteRule(rule.index);
      }
    });

    var defaultStyles = getComputedStyle(node, _window);

    // Enable inline styles
    if (inlineStyle !== "") {
      node.style.cssText = inlineStyle;
    }
    // Enable external and internal styles (note that this has to be done in reversed order)
    definedCSSRules.reverse().forEach(function(rule) {
      if (rule.selectorText !== CSSParserExtension.INLINE_SELECTOR && _isFirstOfGroupedRuleForInsertion(rule)) {
        rule.parentStyleSheet.insertRule(rule.cssText, rule.index);
        // Fix reference for every rule in this group
        cssRules.filter(function(aRule) {
          return rule.groupId === aRule.groupId;
        }).forEach(function(aRule) {
          aRule.rule = rule.parentStyleSheet.cssRules[rule.index];
        });
        delete rule.index;
        delete rule.cssText;
        delete rule.parentStyleSheet;
      }
    });
    // Go back to original ordering
    definedCSSRules.reverse();

    return defaultStyles;
  };

  /* Sometimes multiple selectors in a grouped rule match a node. If that is
     the case, the rule only has to be deleted for the first occurence.*/
  var _isFirstOfGroupedRuleForDeletion = function(rule) {
    return rule.rule.parentStyleSheet || rule.parentStyleSheet;
  };

  /* Sometimes multiple selectors in a grouped rule match a node. If that is
     the case, the rule only has to be inserted for the first occurence.*/
  var _isFirstOfGroupedRuleForInsertion = function(rule) {
    return rule.parentStyleSheet;
  };

  var getComputedStyle = function(node, _window) {
    return _copyCSSPropertiesObject(_window.getComputedStyle(node));
  };

  var getAllComputedStyles = function(node) {
    var computedStyleOfNode = _copyCSSPropertiesObject(window.getComputedStyle(node));
    var computedStylesOfChildren = Utils.flatMap(node.children, function(child) {
      return getAllComputedStyles(child);
    });
    return [computedStyleOfNode].concat(computedStylesOfChildren);
  };

  var _copyCSSPropertiesObject = function(cssStyleDeclaration) {
    var styles = {};
    for (var i = 0; i < cssStyleDeclaration.length; i++) {
      var property = cssStyleDeclaration[i];
      var value = cssStyleDeclaration[property];
      styles[property] = value;
    }
    return styles;
  };

  return {
    getRules: getRules,
    populateNodesWithRules: populateNodesWithRules,
    getDefinedRules: getDefinedRules,
    getImplicitStyles: getImplicitStyles,
    getComputedStyle: getComputedStyle,
    getAllComputedStyles: getAllComputedStyles,
    INLINE_SELECTOR: INLINE_SELECTOR
  };

}());
