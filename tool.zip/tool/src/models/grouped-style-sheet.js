/*global Utils, CustomCSSStyleRule, CSSStyleRule*/

function GroupedStyleSheet(styleSheets) {
  var that = this;

  this._styleSheets = styleSheets;
  this.media = styleSheets[0].media;
  this.href = styleSheets[0].href;
  this.ownerNode = styleSheets[0].ownerNode;
  this.cssRules = Utils.map(styleSheets[0].cssRules, function(cssRule) {
    if (cssRule instanceof CSSStyleRule) {
      return new CustomCSSStyleRule(cssRule, that);
    } else {
      return cssRule;
    }
  });
  this.addStyleSheet = function(styleSheet) {
    this._styleSheets.push(styleSheet);
  };
  this.insertRule = function(cssText, index) {
    this._styleSheets.forEach(function(styleSheet) {
      styleSheet.insertRule(cssText, index);
    });

    var newRule = this._styleSheets[0].cssRules[index];
    var newCustomRule = new CustomCSSStyleRule(newRule, this);
    this.cssRules.splice(index, 0, newCustomRule);
  };
  this.deleteRule = function(index) {
    this._styleSheets.forEach(function(styleSheet) {
      styleSheet.cssRules[index].delete();
    });

    this.cssRules.splice(index, 1);
  };
}

Object.defineProperty(GroupedStyleSheet.prototype, "disabled", {
  get: function() {
    return this._styleSheets[0].disabled;
  },
  set: function(newValue) {
    this._styleSheets.forEach(function(styleSheet) { styleSheet.disabled = newValue; });
  }
});
