/*global CSSStyleRule, Utils, CSSSelectorParser*/

CSSStyleRule.prototype.insertAfter = function(cssText) {
  var index = Utils.indexOf(this.parentStyleSheet.cssRules, this);
  this.parentStyleSheet.insertRule(cssText, index + 1);
  return this.parentStyleSheet.cssRules[index + 1];
};

CSSStyleRule.prototype.delete = function() {
  if (!this.parentStyleSheet) {
    return; // Already removed in earlier refactoring
  }
  var index = Utils.indexOf(this.parentStyleSheet.cssRules, this);
  this.parentStyleSheet.deleteRule(index);
};

CSSStyleRule.prototype.removeSelector = function(selector) {
  var parsedSelectors = CSSSelectorParser.parse(this.selectorText);
  if (!parsedSelectors.selectors) {
    return; // Not a grouped selector
  }
  var remainingSelectors = parsedSelectors.selectors.filter(function(parsedSelector) {
    return CSSSelectorParser.render(parsedSelector) !== selector;
  });
  parsedSelectors.selectors = remainingSelectors;
  var cssText = CSSSelectorParser.render(parsedSelectors) + "{" + this.style.cssText + "}";
  var updatedRule = this.insertAfter(cssText);
  this.delete();
  return updatedRule;
};
