/*global Utils*/

// Assertion: parentStyleSheet is a GroupedStyleSheet
function CustomCSSStyleRule(cssRule, parentStyleSheet) {
  this._rule = cssRule;
  this.parentStyleSheet = parentStyleSheet;
}

Object.defineProperty(CustomCSSStyleRule.prototype, "cssText", {
  get: function() {
    return this._rule.cssText;
  }
});

Object.defineProperty(CustomCSSStyleRule.prototype, "selectorText", {
  get: function() {
    return this._rule.selectorText;
  }
});

Object.defineProperty(CustomCSSStyleRule.prototype, "style", {
  get: function() {
    return this._rule.style;
  }
});

Object.defineProperty(CustomCSSStyleRule.prototype, 'toJSON', {
  value: function () {
    return {};
  },
  configurable: true
});

CustomCSSStyleRule.prototype.insertAfter = function(cssText) {
  var index = Utils.indexOf(this.parentStyleSheet._styleSheets[0].cssRules, this._rule);
  this.parentStyleSheet.insertRule(cssText, index + 1);
  return this.parentStyleSheet.cssRules[index + 1];
};

CustomCSSStyleRule.prototype.delete = function() {
  var index = Utils.indexOf(this.parentStyleSheet._styleSheets[0].cssRules, this._rule);
  this.parentStyleSheet.deleteRule(index);
};

CustomCSSStyleRule.prototype.removeSelector = function(selector) {
  var index = Utils.indexOf(this.parentStyleSheet._styleSheets[0].cssRules, this._rule);
  var updatedRule = this.parentStyleSheet._styleSheets[0].cssRules[index].removeSelector(selector);
  this.parentStyleSheet._styleSheets.slice(1).forEach(function(styleSheet) {
    styleSheet.cssRules[index].removeSelector(selector);
  });

  var updatedCustomRule = new CustomCSSStyleRule(updatedRule, this.parentStyleSheet);
  this.parentStyleSheet.deleteRule(index);
  this.parentStyleSheet.insertRule(updatedCustomRule);
  return updatedCustomRule;
};
