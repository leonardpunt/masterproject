/*global Utils, RefactorUndoingStyle*/

var UndoingStyle = (function() {

  /* A style is undoing style if it has the A-B-A pattern, example:
        .class1 { margin: 0px } -> A
        .class2 { margin: 10px } -> B
        .class3 { margin: 0px } -> and A again
     The latest A is the undoing style, B is the overridden style. */
  var filterUndoingStyle = function(rules, implicitStyles, styleSheets, isMultiple) {
    rules = rules.filter(function(rule) {
      return !_isPseudoClassToIgnore(rule);
    });

    var checkedProperties = [];
    var overridingDeclarations = [];

    rules.forEach(function(rule) {
      Object.keys(rule.declarations).forEach(function(property) {
        if (checkedProperties.indexOf(property) >= 0) {
          return;
        }

        var rulesWithDeclaration = _getRulesWithDeclaration(property, rules);
        rulesWithDeclaration.sort(function(rule1, rule2) {
          return _compareCascadingOrder(rule2, rule1, styleSheets);
        });

        if (rulesWithDeclaration.length > 1) {
          checkedProperties.push(property);
          overridingDeclarations.push({ property: property, rules: rulesWithDeclaration });
        }
      });
    });

    // Find A-B-A pattern
    var smells = [];
    overridingDeclarations.forEach(function(overridingDeclaration) {
      var property = overridingDeclaration.property;
      var implicitValue = implicitStyles[property];
      var implicitStyle = { property: property, value: implicitValue };
      overridingDeclaration.rules.push({ declaration: implicitStyle });

      if (overridingDeclaration.rules.length < 3) {
        return;
      }

      // Detect the A-B*-A patterns
      var detections = _detectABA(overridingDeclaration);

      // Filter all the refactorable A-B-A patterns
      detections.forEach(function(detection) {
        var initialRule = overridingDeclaration.rules[detection.lowestA];
        var enclosedRules = overridingDeclaration.rules
          .slice(detection.highestA + 1, detection.lowestA)
          .map(function(enclosedRule) {
            return {
              declaration: enclosedRule.declaration,
              ruleWrapper: enclosedRule.rule
            };
          }); // Ordered by specificity, highest first
        var resetRule = overridingDeclaration.rules[detection.highestA];

        smells.push({
          isRefactorable: _isRefactorable(initialRule, enclosedRules, resetRule, isMultiple),
          initial: {
            declaration: initialRule.declaration,
            ruleWrapper: initialRule.rule
          },
          enclosed: enclosedRules,
          reset: {
            declaration: resetRule.declaration,
            ruleWrapper: resetRule.rule
          }
        });
      });
    });

    return smells;
  };

  /* Ignore pseudo classes 'first-child', 'last-child', 'nth-child' and
     'nth-last-child' */
  var _isPseudoClassToIgnore = function(rule) {
    var pseudos = rule.selector.rule.pseudos;
    if (!pseudos) {
      return false;
    }

    var pseudoClass = pseudos[0].name;
    return pseudoClass === "first-child" || pseudoClass === "last-child" ||
      pseudoClass === "nth-child" || pseudoClass === "nth-last-child";
  };

  var _getRulesWithDeclaration = function(property, rules) {
    return rules.filter(function(anotherRule) {
      return property in anotherRule.declarations;
    }).map(function(ruleWithDeclaration) {
      var otherDeclaration = ruleWithDeclaration.declarations[property];
      return {
        declaration: {
          property: property,
          value: otherDeclaration.value,
          isImportant: otherDeclaration.isImportant
        },
        rule: ruleWithDeclaration
      };
    });
  };

  var _compareCascadingOrder = function(thisRule, anotherRule, styleSheets) {
    if (thisRule.declaration.isImportant) {
      return 1;
    }
    if (anotherRule.declaration.isImportant) {
      return -1;
    }

    thisRule = thisRule.rule;
    anotherRule = anotherRule.rule;

    var specificity = Utils.compareSpecificity(thisRule.specificity, anotherRule.specificity);
    if (specificity === 0) { // if specificity is equal, check which stylesheet or rule is defined last
      var thisStyleSheet = thisRule.rule.parentStyleSheet;
      var anotherStyleSheet = anotherRule.rule.parentStyleSheet;
      var thisStyleSheetIndex = _indexOfStyleSheet(thisStyleSheet, styleSheets);
      var anotherStyleSheetIndex = _indexOfStyleSheet(anotherStyleSheet, styleSheets);

      if (_isStyleSheetListedLater(thisStyleSheetIndex, anotherStyleSheetIndex)) {
        return 1;
      } else if (_isStyleSheetListedLater(anotherStyleSheetIndex, thisStyleSheetIndex)) {
        return -1;
      } else {
        var isRuleListedLater = _isRuleListedLater(thisStyleSheet, thisRule.rule, anotherRule.rule, thisRule.selectorText, anotherRule.selectorText);
        if (isRuleListedLater === undefined) {
          throw new Error("Assertion error. Rules not found.");
        }
        return isRuleListedLater ? 1 : -1;
      }
    } else {
      return specificity;
    }
  };

  var _indexOfStyleSheet = function(styleSheet, styleSheets) {
    return Utils.indexOf(styleSheets, styleSheet);
  };

  var _isStyleSheetListedLater = function(thisStyleSheetIndex, anotherStyleSheetIndex) {
    return thisStyleSheetIndex > anotherStyleSheetIndex;
  };

  var _isRuleListedLater = function(styleSheet, rule1, rule2, selectorText1, selectorText2) {
    // Compare styles, because for some reason two equal CustomCSSStyleRules have different references
    if (rule1.style === rule2.style) {
      // Grouped rule
      var index1 = rule1.selectorText.indexOf(selectorText1 + ",");
      var index2 = rule1.selectorText.indexOf(selectorText2 + ",");

      if (index1 === -1) {
        // index1 is last, since there is no match on the selectorText with a comma appended
        return true;
      } else if (index2 === -1) {
        // index2 is last, since there is no match on the selectorText with a comma appended
        return false;
      } else {
        return index1 > index2;
      }
    }

    for (var i = 0; i < styleSheet.cssRules.length; i++) {
      var thisRule = styleSheet.cssRules[i];
      if (thisRule.style === rule1.style) {
        return false;
      } else if (thisRule.style === rule2.style) {
        return true;
      }
    }
    return undefined;
  };

  // Check for A-B*-A pattern, by looking for the largest match first
  // The rule with the highest specificity is at index 0
  var _detectABA = function(overridingDeclaration) {
    // highestA is the A with the highest specificty
    var lowestA, highestA;
    var length = overridingDeclaration.rules.length;
    var detections = [];

    for (var indexhighestA = 0; indexhighestA < length - 1; indexhighestA++) {
      highestA = overridingDeclaration.rules[indexhighestA];

      for (var indexlowestA = length - 1; indexlowestA > indexhighestA; indexlowestA--) {
        lowestA = overridingDeclaration.rules[indexlowestA];

        if (lowestA.declaration.value === highestA.declaration.value) {
          // Check if this detection is a part of a previous detection, if so: ignore
          if (!_isPartOfPreviousDetection(indexlowestA, indexhighestA, detections)) {
            var values = _getValues(indexlowestA, indexhighestA, overridingDeclaration.rules).join(", ");
            detections.push({
              lowestA: indexlowestA,
              highestA: indexhighestA
            });
            break;
          }
        }
      }
    }

    return detections;
  };

  var _isPartOfPreviousDetection = function(indexlowestA, indexhighestA, detections) {
    return detections.filter(function(detection) {
      return detection.lowestA >= indexlowestA && detection.highestA <= indexhighestA;
    }).length > 0;
  };

  var _getValues = function(indexlowestA, indexhighestA, rules) {
    return rules
      .slice(indexhighestA, indexlowestA + 1)
      .reverse()
      .map(function(rule) { return rule.declaration.value; });
  };

  var _isRefactorable = function(initialRule, enclosedRules, resetRule, isMultiple) {
    // No support for refactoring anything other than A-B-A yet.
    if (enclosedRules.length !== 1) {
      return false;
    } else {
      // Precondition 1: the most specific unit of the selector of the enclosed rule should not be an element
      var selectorUnit = RefactorUndoingStyle.getMostSpecificSelectorUnit(enclosedRules[0].ruleWrapper.selector);
      if (selectorUnit.tagName && !selectorUnit.classNames) {
        return false;
      }

      // Precondition2: the elements of ruleA have to be a subset of the elements of rule
      if (!initialRule.rule) { // If implicit style, we cannot check if the precondition holds
        return false;
      }
      var elementsInitialRule = _querySelectorAll(initialRule.rule.selectorText, isMultiple);
      var elementsResetRule = _querySelectorAll(resetRule.rule.selectorText, isMultiple);
      var isSubset = elementsResetRule.every(function(elementResetRule) {
        return elementsInitialRule.indexOf(elementResetRule) > -1;
      });
      return isSubset;
    }
  };

  var _querySelectorAll = function(selectorText, isMultiple) {
    if (isMultiple) {
      return Utils.flatMap(window.frames, function (frame) {
        return Utils.map(frame.document.querySelectorAll(selectorText), function(node) { return node; });
      });
    } else {
      return Utils.map(document.querySelectorAll(selectorText), function(node) { return node; });
    }
  };

  var api = {
    filterUndoingStyle: filterUndoingStyle
  };

  /* test-code */
  api._compareCascadingOrder = _compareCascadingOrder;
  api._isRuleListedLater = _isRuleListedLater;
  api._detectABA = _detectABA;
  /* end-test-code */

  return api;

}());
