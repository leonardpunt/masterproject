var Utils = (function() {

  var map = function(arr, func) {
    return arr ? Array.prototype.map.call(arr, func) : [];
  };

  var flatten = function(arr) {
    return Array.prototype.concat.apply([], arr);
  };

  var filter = function(arr, func) {
    return arr ? Array.prototype.filter.call(arr, func) : [];
  };

  var flatMap = function(arr, func) {
    return flatten(map(arr, func));
  };

  var forEach = function(arr, func) {
    return Array.prototype.forEach.call(arr, func);
  };

  var some = function(arr, func) {
    return arr ? Array.prototype.some.call(arr, func) : false;
  };

  var indexOf = function(arr, el) {
    return Array.prototype.indexOf.call(arr, el);
  };

  var reduce = function(arr, func, initialValue) {
    return Array.prototype.reduce.call(arr, func, initialValue);
  };

  var diff = function(arr1, arr2) {
    return filter(arr1, function(el) { return indexOf(arr2, el) < 0; });
  };

  // source: http://stackoverflow.com/questions/105034/create-guid-uuid-in-javascript
  var guid = function() {
    function s4() {
      return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
    }
    return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
  };

  var compareSpecificity = function(specificity1, specificity2) {
    for (var i = 0; i < 4; i++) {
      if (specificity1[i] > specificity2[i]) {
        return 1;
      } else if (specificity1[i] < specificity2[i]) {
        return -1;
      }
    }
    return 0;
  };

  return {
    map: map,
    flatten: flatten,
    filter: filter,
    flatMap: flatMap,
    forEach: forEach,
    some: some,
    indexOf: indexOf,
    reduce: reduce,
    diff: diff,
    guid: guid,
    compareSpecificity: compareSpecificity
  };

}());
