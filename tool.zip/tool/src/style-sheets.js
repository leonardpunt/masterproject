/*global Utils, GroupedStyleSheet*/

var StyleSheets = (function() {

  var getStyleSheetsForDocument = function(_document, styleSheets) {
    var originalStyleSheets = _sortStyleSheets(_removeDuplicateStyleSheets(Utils.flatten(_document.styleSheets)));

    return originalStyleSheets.map(function(styleSheet) {
      return _getStyleSheet(styleSheets, styleSheet);
    });
  };

  var getAllStyleSheets = function(isMultiple) {
    if (isMultiple) {
      var styleSheets = [];

      // Check if the one of the style sheets is used in another iframe
      for (var i = 0; i < frames.length; i++) {
        var styleSheetsForFrame = _removeDuplicateStyleSheets(Utils.flatten(frames[i].document.styleSheets));

        for (var j = 0; j < styleSheetsForFrame.length; j++) {
          var styleSheet = styleSheetsForFrame[j];

          // Try to group the same style sheets
          var existingStyleSheet = _getStyleSheet(styleSheets, styleSheet);
          if (existingStyleSheet) {
            var index = styleSheets.indexOf(existingStyleSheet);
            if (existingStyleSheet instanceof GroupedStyleSheet) {
              styleSheets[index].addStyleSheet(styleSheet);
            } else {
              styleSheets[index] = new GroupedStyleSheet([styleSheets[index], styleSheet]);
            }
          } else {
            styleSheets.push(styleSheet);
          }
        }
      }

      return _sortStyleSheets(styleSheets);
    } else {
      return _sortStyleSheets(_removeDuplicateStyleSheets(Utils.flatten(document.styleSheets)));
    }
  };

  var _getStyleSheet = function(styleSheets, styleSheet) {
    return styleSheets.filter(function(s) {
      return s.ownerNode === styleSheet.ownerNode;
    })[0];
  };

  var _sortStyleSheets = function(styleSheets) {
    var externalStyleSheets = [];
    var internalStyleSheets = [];

    styleSheets.forEach(function(styleSheet) {
      var arr = styleSheet.href ? externalStyleSheets : internalStyleSheets;
      arr.push(styleSheet);
    });

    return externalStyleSheets.concat(internalStyleSheets);
  };

  var _removeDuplicateStyleSheets = function(styleSheets) {
    var seen = {};
    return styleSheets.filter(function(item) {
      if (!item.href) {
          return true;
      }
      return seen.hasOwnProperty(item.href) ? false : (seen[item.href] = true);
    });
  };

  return {
    getStyleSheetsForDocument: getStyleSheetsForDocument,
    getAllStyleSheets: getAllStyleSheets
  };

}());
