/*global module, test, strictEqual, notStrictEqual*/
/*global RefactorUndoingStyle*/

var A_PROPERTY = "font-weight";
var A_DECLARATION = {
  property: A_PROPERTY,
  value: "normal",
  isImportant: false
};
var ANOTHER_PROPERTY = "color";
var ANOTHER_DECLARATION = {
  property: ANOTHER_PROPERTY,
  value: "red",
  isImportant: false
};
var AN_ID = "0";
var A_GROUP_ID = "a";
var ANOTHER_ID = "1";
var ANOTHER_GROUP_ID = "b";

module("'updateReferences' should correctly perform 'property moved to new rule' updates");
  test("in the ruleWrapper", function() {
    var groupedEnclosedRules = [[{
      smell: {
        initial: {},
        enclosed: [{
          declaration: A_DECLARATION,
          ruleWrapper: {
            id: AN_ID,
            groupId: A_GROUP_ID
          }
        }],
        reset: {
          declaration: A_DECLARATION,
          ruleWrapper: {
            id: ANOTHER_ID,
            groupId: ANOTHER_GROUP_ID
          }
        }
      },
      nodes: []
    }]];
    var newRuleWrapper = "newRuleWrapper";
    var updates = [{
      id: AN_ID,
      property: A_PROPERTY,
      newRuleWrapper: newRuleWrapper
    }];

    // Should update one rule, because of same id and property.
    var updatedRules = RefactorUndoingStyle.updateReferences(groupedEnclosedRules, updates);
    strictEqual(updatedRules[0][0].smell.enclosed[0].ruleWrapper, newRuleWrapper);
    notStrictEqual(updatedRules[0][0].smell.reset.ruleWrapper, newRuleWrapper);
  });

  test("in the undoingStyles", function() {
    var groupedEnclosedRules = [[{
      smell: {
        initial: {},
        enclosed: [{
          declaration: A_DECLARATION,
          ruleWrapper: {
            id: AN_ID,
            groupId: A_GROUP_ID
          }
        }],
        reset: {
          declaration: A_DECLARATION,
          ruleWrapper: {
            id: ANOTHER_ID,
            groupId: ANOTHER_GROUP_ID
          }
        }
      },
      nodes: []
    },
    {
      smell: {
        initial: {},
        enclosed: [{
          declaration: A_DECLARATION,
          ruleWrapper: {
            id: AN_ID,
            groupId: A_GROUP_ID
          }
        }],
        reset: {
          declaration: ANOTHER_DECLARATION,
          ruleWrapper: {
            id: ANOTHER_ID,
            groupId: ANOTHER_GROUP_ID
          }
        }
      },
      nodes: []
    }]];
    var newRuleWrapper = "newRuleWrapper";
    var updates = [{
      id: ANOTHER_ID,
      property: A_PROPERTY,
      newRuleWrapper: newRuleWrapper
    }];

    // Should update only one undoing style rule, because of same id and property.
    var updatedRules = RefactorUndoingStyle.updateReferences(groupedEnclosedRules, updates);
    strictEqual(updatedRules[0][0].smell.reset.ruleWrapper, newRuleWrapper);
    notStrictEqual(updatedRules[0][1].smell.reset.ruleWrapper, newRuleWrapper);
    notStrictEqual(updatedRules[0][0].smell.enclosed[0].ruleWrapper, newRuleWrapper);
    notStrictEqual(updatedRules[0][1].smell.enclosed[0].ruleWrapper, newRuleWrapper);
  });

module("'updateReferences' should correctly perform 'property removed from grouped selector' updates");
  test("in the ruleWrapper", function() {
    var groupedEnclosedRules = [[{
      smell: {
        initial: {},
        enclosed: [{
          declaration: A_DECLARATION,
          ruleWrapper: {
            id: AN_ID,
            groupId: A_GROUP_ID
          }
        }],
        reset: {
          declaration: A_DECLARATION,
          ruleWrapper: {
            id: ANOTHER_ID,
            groupId: ANOTHER_GROUP_ID
          }
        }
      },
      nodes: []
    }], [{
      smell: {
        initial: {},
        enclosed: [{
          declaration: ANOTHER_DECLARATION,
          ruleWrapper: {
            id: ANOTHER_ID,
            groupId: A_GROUP_ID
          }
        }],
        reset: {
          declaration: ANOTHER_DECLARATION,
          ruleWrapper: {
            id: ANOTHER_ID,
            groupId: ANOTHER_GROUP_ID
          }
        }
      },
      nodes: []
    }]];

    var newRuleWrapper1 = "oldGroup";
    var newRuleWrapper2 = "newRuleWrapper";
    var updates = [{
      groupId: A_GROUP_ID,
      newRuleWrapper: newRuleWrapper1
    },
    {
      id: AN_ID,
      newRuleWrapper: newRuleWrapper2
    }];

    // Should update both rules, because of same groupId, despite the property.
    var updatedRules = RefactorUndoingStyle.updateReferences(groupedEnclosedRules, updates);
    strictEqual(updatedRules[0][0].smell.enclosed[0].ruleWrapper, newRuleWrapper2); // Because this rule is splitted from the grouped rule
    strictEqual(updatedRules[1][0].smell.enclosed[0].ruleWrapper, newRuleWrapper1); // Because it is in the grouped rule, which is updated
    notStrictEqual(updatedRules[0][0].smell.reset.ruleWrapper, newRuleWrapper1); // Because it is not in the grouped rule
    notStrictEqual(updatedRules[1][0].smell.reset.ruleWrapper, newRuleWrapper1); // Because it is not in the grouped rule
  });

  test("in the undoingStyles", function() {
    var groupedEnclosedRules = [[{
      smell: {
        initial: {},
        enclosed: [{
          declaration: A_DECLARATION,
          ruleWrapper: {
            id: AN_ID,
            groupId: A_GROUP_ID
          }
        }],
        reset: {
          declaration: A_DECLARATION,
          ruleWrapper: {
            id: ANOTHER_ID,
            groupId: ANOTHER_GROUP_ID
          }
        }
      },
      nodes: []
    }],
    [{
      smell: {
        initial: {},
        enclosed: [{
          declaration: ANOTHER_DECLARATION,
          ruleWrapper: {
            id: AN_ID,
            groupId: A_GROUP_ID
          }
        }],
        reset: {
          declaration: ANOTHER_DECLARATION,
          ruleWrapper: {
            id: AN_ID,
            groupId: ANOTHER_GROUP_ID
          }
        }
      }
    }]];

    var newRuleWrapper1 = "oldGroup";
    var newRuleWrapper2 = "newRuleWrapper";
    var updates = [{
      groupId: ANOTHER_GROUP_ID,
      newRuleWrapper: newRuleWrapper1
    },
    {
      id: ANOTHER_ID,
      newRuleWrapper: newRuleWrapper2
    }];

    // Should update both undoing style rules, because of same groupId, despite the property.
    var updatedRules = RefactorUndoingStyle.updateReferences(groupedEnclosedRules, updates);
    strictEqual(updatedRules[0][0].smell.reset.ruleWrapper, newRuleWrapper2); // Because this rule is splitted from the grouped rule
    strictEqual(updatedRules[1][0].smell.reset.ruleWrapper, newRuleWrapper1); // Because it is in the grouped rule, which is updated
    notStrictEqual(updatedRules[0][0].smell.enclosed[0].ruleWrapper, newRuleWrapper1); // Because it is not in the grouped rule
    notStrictEqual(updatedRules[1][0].smell.enclosed[0].ruleWrapper, newRuleWrapper1); // Because it is not in the grouped rule
  });

