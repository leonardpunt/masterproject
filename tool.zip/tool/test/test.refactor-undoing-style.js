/*global test, ok, notOk, strictEqual, notStrictEqual, module*/
/*global RefactorUndoingStyle, Utils*/

var STYLE = ".test {"+
  "border-bottom-style: none"+
"}"+
"p {"+
  "border-bottom-style: solid"+
"}";
var SMELL = [{
  smell: {
    isRefactorable: true,
    initial: {
      ruleWrapper: {
        rule: undefined,
        selector: {
          rule: {
            tagName: "p",
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: "p",
        specificity: [0,0,0,1],
        declarations: {
          "border-bottom-style": {
            value: "none",
            isImportant: false
          }
        }
      },
      declaration: {
        property: "border-bottom-style",
        value: "none",
        isImportant: false
      }
    },
    enclosed: [{
      ruleWrapper: {
        rule: undefined,
        selector: {
          rule: {
            tagName: "p",
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: "p",
        specificity: [0,0,0,1],
        declarations: {
          "border-bottom-style": {
            value: "solid",
            isImportant: false
          }
        },
      },
      declaration: {
        property: "border-bottom-style",
        value: "solid",
        isImportant: false
      }
    }],
    reset: {
      ruleWrapper: {
        rule: undefined,
        selector: {
          rule: {
            classNames: [ "test" ],
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: ".test",
        specificity: [0,0,1,0],
        declarations: {
          "border-bottom-style": {
            value: "none",
            isImportant: false
          }
        }
      },
      declaration: {
        property: "border-bottom-style",
        value: "none",
        isImportant: false
      }
    }
  },
  nodes: []
}];
var SHORTHAND_STYLE = ".test {"+
  "margin-left: 0px"+
"}"+
"p {"+
  "margin: 50px"+
"}";
var SHORTHAND_SMELL = [{
  smell: {
    isRefactorable: true,
    initial: {
      ruleWrapper: {
        rule: undefined,
        selector: {
          type: "ruleSet",
          rule: {
            tagName: "p",
            type: "rule"
          }
        },
        selectorText: "p",
        specificity: [0,0,0,1],
        declarations: {
          "color": {
            value: "green",
            isImportant: false
          },
          "margin-left": {
            value: "0px",
            isImportant: false
          }
        }
      },
      declaration: {
        property: "margin-left",
        value: "0px",
        isImportant: false
      }
    },
    enclosed: [{
      ruleWrapper: {
        rule: undefined,
        selector: {
          type: "ruleSet",
          rule: {
            tagName: "p",
            type: "rule"
          }
        },
        selectorText: "p",
        specificity: [0,0,0,1],
        declarations: {
          "color": {
            value: "red",
            isImportant: false
          },
          "margin-top": {
            value: "50px",
            isImportant: false
          },
          "margin-right": {
            value: "50px",
            isImportant: false
          },
          "margin-bottom": {
            value: "50px",
            isImportant: false
          },
          "margin-left": {
            value: "50px",
            isImportant: false
          }
        }
      },
      declaration: {
        property: "margin-left",
        value: "50px",
        isImportant: false
      }
    }],
    reset: {
      ruleWrapper: {
        rule: undefined,
        selector: {
          type: "ruleSet",
          rule: {
            classNames: ["test"],
            type: "rule"
          }
        },
        selectorText: ".test",
        specificity: [0,0,1,0],
        declarations: {
          "color": {
            value: "green",
            isImportant: false
          },
          "margin-left": {
            value: "0px",
            isImportant: false
          }
        }
      },
      declaration: {
        property: "margin-left",
        value: "0px",
        isImportant: false
      }
    }
  },
  nodes: []
}];
var INLINE_STYLE_PROPERTY = "margin-left";
var INLINE_STYLE_VALUE = "0px";
var INLINE_STYLE_STYLESHEET = ".test {"+
  "margin-left: 50px;"+
"}";
var INLINE_SMELL = [{
  smell: {
    isRefactorable: true,
    initial: {
      ruleWrapper: {
        rule: undefined,
        selector: {
          type: "ruleSet",
          rule: {
            tagName: "p",
            type: "rule"
          }
        },
        selectorText: "p",
        specificity: [0,0,0,1],
        declarations: {
          "margin-left": {
            value: "0px",
            isImportant: false
          }
        }
      },
      declaration: {
        property: "margin-left",
        value: "0px",
        isImportant: false
      }
    },
    enclosed: [{
      ruleWrapper: {
        rule: undefined,
        selector: {
          type: "ruleSet",
          rule: {
            classNames: ["test"],
            type: "rule"
          }
        },
        selectorText: ".test",
        specificity: [0,0,1,0],
        declarations: {
          "margin-left": {
            value: "50px",
            isImportant: false
          }
        }
      },
      declaration: {
        property: "margin-left",
        value: "50px",
        isImportant: false
      }
    }],
    reset: {
      ruleWrapper: {
        rule: {
          selectorText: "_inline"
        },
        selector: {
          rule: {}
        },
        selectorText: "_inline",
        specificity: [1,0,0,0],
        declarations: {
          "margin-left": {
            value: "0px",
            isImportant: false
          }
        }
      },
      declaration: {
        property: "margin-left",
        value: "0px",
        isImportant: false
      }
    }
  },
  nodes: []
}];
var MULTIPLE_RESET_STYLE = ".test {"+
  "border-bottom-style: none"+
"}"+
".barf {"+
  "border-bottom-style: none"+
"}"+
"p {"+
  "border-bottom-style: solid"+
"}";
var MULTIPLE_RESET_SMELL = [
{
  smell: {
    isRefactorable: true,
    initial: {
      ruleWrapper: {
        id: 0,
        groupId: 0,
        rule: undefined,
        selector: {
          rule: {
            tagName: "p",
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: "p",
        specificity: [0,0,0,1],
        declarations: {
          "border-bottom-style": {
            value: "none",
            isImportant: false
          }
        }
      },
      declaration: {
        property: "border-bottom-style",
        value: "none",
        isImportant: false
      }
    },
    enclosed: [{
      ruleWrapper: {
        id: 1,
        groupId: 1,
        rule: undefined,
        selector: {
          rule: {
            tagName: "p",
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: "p",
        specificity: [0,0,0,1],
        declarations: {
          "border-bottom-style": {
            value: "solid",
            isImportant: false
          }
        },
      },
      declaration: {
        property: "border-bottom-style",
        value: "solid",
        isImportant: false
      }
    }],
    reset: {
      ruleWrapper: {
        id: 2,
        groupId: 2,
        rule: undefined,
        selector: {
          rule: {
            classNames: [ "test" ],
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: ".test",
        specificity: [0,0,1,0],
        declarations: {
          "border-bottom-style": {
            value: "none",
            isImportant: false
          }
        }
      },
      declaration: {
        property: "border-bottom-style",
        value: "none",
        isImportant: false
      }
    }
  },
  nodes: []
}, {
  smell: {
    isRefactorable: true,
    initial: {
      ruleWrapper: {
        id: 4,
        groupId: 4,
        rule: undefined,
        selector: {
          rule: {
            tagName: "p",
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: "p",
        specificity: [0,0,0,1],
        declarations: {
          "border-bottom-style": {
            value: "none",
            isImportant: false
          }
        }
      },
      declaration: {
        property: "border-bottom-style",
        value: "none",
        isImportant: false
      }
    },
    enclosed: [{
      ruleWrapper: {
        id: 1,
        groupId: 1,
        rule: undefined,
        selector: {
          rule: {
            tagName: "p",
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: "p",
        specificity: [0,0,0,1],
        declarations: {
          "border-bottom-style": {
            value: "solid",
            isImportant: false
          }
        },
      },
      declaration: {
        property: "border-bottom-style",
        value: "solid",
        isImportant: false
      }
    }],
    reset: {
      ruleWrapper: {
        id: 3,
        groupId: 3,
        rule: undefined,
        selector: {
          rule: {
            classNames: [ "barf" ],
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: ".barf",
        specificity: [0,0,1,0],
        declarations: {
          "border-bottom-style": {
            value: "none",
            isImportant: false
          }
        }
      },
      declaration: {
        property: "border-bottom-style",
        value: "none",
        isImportant: false
      }
    }
  },
  nodes: []
}];
var GUID = "12345";



module("refactor should create new CSS class in stylesheet", {
  beforeEach: function() {
    Utils.guid = function() { return GUID; };
  }
});

  test("with correct name", function() {
    var smell = JSON.parse(JSON.stringify(SMELL));
    setup(STYLE, smell);

    RefactorUndoingStyle.refactor(smell);

    var expectedSelectorText = ".refactoring-" + GUID;
    var foundRules = Utils.filter(document.styleSheets[0].cssRules, function(cssRule) {
      return cssRule.selectorText === expectedSelectorText;
    });

    strictEqual(foundRules.length, 1);
  });

  test("at correct index", function() {
    var smell = JSON.parse(JSON.stringify(SMELL));
    setup(STYLE, smell);

    RefactorUndoingStyle.refactor(smell);

    var selectorText = ".refactoring-" + GUID;
    var expectedIndex = 0;

    strictEqual(document.styleSheets[0].cssRules[expectedIndex].selectorText, selectorText);
  });


  test("with correct declaration", function() {
    var smell = JSON.parse(JSON.stringify(SMELL));
    setup(STYLE, smell);

    RefactorUndoingStyle.refactor(smell);

    var expectedProperty = "border-bottom-style";
    var expectedValue = "solid";

    strictEqual(document.styleSheets[0].cssRules[0].style[0], expectedProperty);
    strictEqual(document.styleSheets[0].cssRules[0].style[expectedProperty], expectedValue);
  });

  test("with correct property if overridden style is shorthand property", function() {
    var smell = JSON.parse(JSON.stringify(SHORTHAND_SMELL));
    setup(SHORTHAND_STYLE, smell);

    RefactorUndoingStyle.refactor(smell);

    var overriddenStyleRuleIndex = 1;
    var expectedProperty = "margin-left";
    var expectedValue = "50px";

    strictEqual(document.styleSheets[0].cssRules[overriddenStyleRuleIndex].style.length, 1);
    strictEqual(document.styleSheets[0].cssRules[overriddenStyleRuleIndex].style[0], expectedProperty);
    strictEqual(document.styleSheets[0].cssRules[overriddenStyleRuleIndex].style[expectedProperty], expectedValue);
  });



module("refactor should remove property from overridden style and delete empty rule");
  test("for normal property", function() {
    var smell = JSON.parse(JSON.stringify(SMELL));
    setup(STYLE, smell);

    RefactorUndoingStyle.refactor(smell);

    strictEqual(document.styleSheets[0].cssRules.length, 1);
  });

  test("for shorthand property", function() {
    var smell  = JSON.parse(JSON.stringify(SHORTHAND_SMELL));
    setup(SHORTHAND_STYLE, smell);

    RefactorUndoingStyle.refactor(smell);

    var overriddenStyleRuleIndex = 0;
    var expectedProperty1 = "margin-top";
    var expectedProperty2 = "margin-right";
    var expectedProperty3 = "margin-bottom";
    var expectedValue = "50px";

    strictEqual(document.styleSheets[0].cssRules[overriddenStyleRuleIndex].style.length, 3);
    strictEqual(document.styleSheets[0].cssRules[overriddenStyleRuleIndex].style[0], expectedProperty1);
    strictEqual(document.styleSheets[0].cssRules[overriddenStyleRuleIndex].style[expectedProperty1], expectedValue);
    strictEqual(document.styleSheets[0].cssRules[overriddenStyleRuleIndex].style[1], expectedProperty2);
    strictEqual(document.styleSheets[0].cssRules[overriddenStyleRuleIndex].style[expectedProperty2], expectedValue);
    strictEqual(document.styleSheets[0].cssRules[overriddenStyleRuleIndex].style[2], expectedProperty3);
    strictEqual(document.styleSheets[0].cssRules[overriddenStyleRuleIndex].style[expectedProperty3], expectedValue);
  });

  test("for inline property", function() {
    // Setup
    $('style').html(INLINE_STYLE_STYLESHEET);
    $('.test').css(INLINE_STYLE_PROPERTY, INLINE_STYLE_VALUE);
    var smell = JSON.parse(JSON.stringify(INLINE_SMELL));
    smell[0].smell.enclosed[0].ruleWrapper.rule = document.styleSheets[0].cssRules[0];
    smell[0].nodes = [$('.test')[0]];

    RefactorUndoingStyle.refactor(smell);

    strictEqual(document.styleSheets[0].cssRules.length, 1);
  });

  test("if smell is reset multiple times", function() {
    var smell = JSON.parse(JSON.stringify(MULTIPLE_RESET_SMELL));
    setupMultipleReset(smell);

    RefactorUndoingStyle.refactor(smell);

    strictEqual(document.styleSheets[0].cssRules.length, 1);
  });



module("refactor should add class attribute to DOM", {
  beforeEach: function() {
    Utils.guid = function() { return GUID; };
  }
});
  test("if element had no class", function() {
    var smell  = JSON.parse(JSON.stringify(SMELL));
    setup(STYLE, smell);

    RefactorUndoingStyle.refactor(smell);

    var paragraphWithAddedClass = document.getElementById("qunit-fixture").getElementsByTagName("p")[0];
    var expectedClassName = "refactoring-" + GUID;

    strictEqual(paragraphWithAddedClass.className, expectedClassName);
  });

  test("if element has already a class", function() {
    var smell  = JSON.parse(JSON.stringify(SMELL));
    setup(STYLE, smell);
    var existingClassName = document.getElementById("qunit-fixture").getElementsByTagName("p")[1].className;

    RefactorUndoingStyle.refactor(smell);

    var paragraphWithAddedClass = document.getElementById("qunit-fixture").getElementsByTagName("p")[1];
    var expectedClassName = existingClassName + " refactoring-" + GUID;

    strictEqual(paragraphWithAddedClass.className, expectedClassName);
  });



module("refactor should remove property from undoing style and delete empty rule");
  test("for normal property", function() {
    var smell  = JSON.parse(JSON.stringify(SMELL));
    setup(STYLE, smell);

    RefactorUndoingStyle.refactor(smell);

    strictEqual(document.styleSheets[0].cssRules.length, 1);
    notStrictEqual(document.styleSheets[0].cssRules[0].selectorText, ".test");
  });

  test("for shorthand property", function() {
    var smell  = JSON.parse(JSON.stringify(SHORTHAND_SMELL));
    setup(SHORTHAND_STYLE, smell);

    RefactorUndoingStyle.refactor(smell);

    strictEqual(document.styleSheets[0].cssRules.length, 2);
    notStrictEqual(document.styleSheets[0].cssRules[0].selectorText, ".test");
  });

  test("for inline property", function() {
    // Setup
    $('style').html(INLINE_STYLE_STYLESHEET);
    $('.test').css(INLINE_STYLE_PROPERTY, INLINE_STYLE_VALUE);
    var smell = JSON.parse(JSON.stringify(INLINE_SMELL));
    smell[0].smell.enclosed[0].ruleWrapper.rule = document.styleSheets[0].cssRules[0];
    smell[0].nodes = [$('.test')[0]];

    RefactorUndoingStyle.refactor(smell);

    strictEqual($('.test')[0].style.length, 0);
    notOk($('.test')[0].hasAttribute('style'));
  });

  test("if smell is reset multiple times", function() {
    var smell = JSON.parse(JSON.stringify(MULTIPLE_RESET_SMELL));
    setupMultipleReset(smell);

    RefactorUndoingStyle.refactor(smell);

    strictEqual(document.styleSheets[0].cssRules.length, 1);
    notStrictEqual(document.styleSheets[0].cssRules[0].selectorText, ".test");
    notStrictEqual(document.styleSheets[0].cssRules[0].selectorText, ".barf");
  });



module("_newSelector should create correct new selector", {
  beforeEach: function() {
    Utils.guid = function() { return GUID; };
  }
});
  test("for element", function() {
    var existingSelector = {
      rule: {
        tagName: "p",
        type: "rule"
      },
      type: "ruleSet"
    };
    var result = ".refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });

  test("for element nested in element", function() {
    var existingSelector = {
      rule: {
        tagName: "div",
        rule: {
          tagName: "p",
          nestingOperator: null,
          type: "rule"
        },
        type: "rule"
      },
      type: "ruleSet"
    };
    var result = "div .refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });

  test("for element nested in class", function() {
    var existingSelector = {
      rule: {
        classNames: ["class"],
        rule: {
          tagName: "p",
          nestingOperator: null,
          type: "rule"
        },
        type: "rule"
      },
      type: "ruleSet"
    };
    var result = ".class .refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });

  test("for element nested in id", function() {
    var existingSelector = {
      rule: {
        id: "id1",
        rule: {
          tagName: "p",
          nestingOperator: null,
          type: "rule"
        },
        type: "rule"
      },
      type: "ruleSet"
    };
    var result = "#id1 .refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });

  test("for element nested in element as child", function() {
    var existingSelector = {
      rule: {
        tagName: "div",
        rule: {
          tagName: "p",
          nestingOperator: ">",
          type: "rule"
        },
        type: "rule"
      },
      type: "ruleSet"
    };
    var result = "div > .refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });

  test("for element nested in element as adjacent sibling", function() {
    var existingSelector = {
      rule: {
        tagName: "div",
        rule: {
          tagName: "p",
          nestingOperator: "+",
          type: "rule"
        },
        type: "rule"
      },
      type: "ruleSet"
    };
    var result = "div + .refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });

  test("for element nested in element as general sibling", function() {
    var existingSelector = {
      rule: {
        tagName: "div",
        rule: {
          tagName: "p",
          nestingOperator: "~",
          type: "rule"
        },
        type: "rule"
      },
      type: "ruleSet"
    };
    var result = "div ~ .refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });

  test("for class", function() {
    var existingSelector = {
      rule: {
        classNames: ["class"],
        type: "rule"
      },
      type: "ruleSet"
    };
    var result = ".refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });

  test("for class nested in element", function() {
    var existingSelector = {
      rule: {
        tagName: "p",
        rule: {
          classNames: ["clazz"],
          nestingOperator: null,
          type: "rule"
        },
        type: "rule"
      },
      type: "ruleSet"
    };
    var result = "p .refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });

  test("for class nested in class", function() {
    var existingSelector = {
      rule: {
        classNames: ["class"],
        rule: {
          classNames: ["clazz"],
          nestingOperator: null,
          type: "rule"
        },
        type: "rule"
      },
      type: "ruleSet"
    };
    var result = ".class .refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });

  test("for class nested in id", function() {
    var existingSelector = {
      rule: {
        id: "id1",
        rule: {
          classNames: ["clazz"],
          nestingOperator: null,
          type: "rule"
        },
        type: "rule"
      },
      type: "ruleSet"
    };
    var result = "#id1 .refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });

  test("for class adjoining an element", function() {
    var existingSelector = {
      rule: {
        tagName: "p",
        classNames: ["clazz"],
        type: "rule"
      },
      type: "ruleSet"
    };
    var result = "p.refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });

  test("for class adjoining a class", function() {
    var existingSelector = {
      rule: {
        classNames: ["class", "clazz"],
        type: "rule"
      },
      type: "ruleSet"
    };
    var result = ".class.refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });

  test("for class adjoining multiple classes", function() {
    var existingSelector = {
      rule: {
        classNames: ["class1", "class2", "class3", "class4"],
        type: "rule"
      },
      type: "ruleSet"
    };
    var result = ".class1.class2.class3.refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });

  test("for class adjoining multiple classes and element", function() {
    var existingSelector = {
      rule: {
        tagName: "p",
        classNames: ["class1", "class2", "class3", "class4"],
        type: "rule"
      },
      type: "ruleSet"
    };
    var result = "p.class1.class2.class3.refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });

  test("for class adjoining an id", function() {
    var existingSelector = {
      rule: {
        id: "id1",
        classNames: ["clazz"],
        type: "rule"
      },
      type: "ruleSet"
    };
    var result = "#id1.refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });

  test("for id", function() {
    var existingSelector = {
      rule: {
        id: "id1",
        type: "rule"
      },
      type: "ruleSet"
    };
    var result = "#id1.refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });

  test("for id nested in element", function() {
    var existingSelector = {
      rule: {
        tagName: "p",
        rule: {
          id: "id2",
          nestingOperator: null,
          type: "rule"
        },
        type: "rule"
      },
      type: "ruleSet"
    };
    var result = "p #id2.refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });

  test("for id nested in class", function() {
    var existingSelector = {
      rule: {
        classNames: ["class"],
        rule: {
          id: "id2",
          nestingOperator: null,
          type: "rule"
        },
        type: "rule"
      },
      type: "ruleSet"
    };
    var result = ".class #id2.refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });

  test("for id nested in id", function() {
    var existingSelector = {
      rule: {
        id: "id1",
        rule: {
          id: "id2",
          nestingOperator: null,
          type: "rule"
        },
        type: "rule"
      },
      type: "ruleSet"
    };
    var result = "#id1 #id2.refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });

  test("for id adjoining an element", function() {
    var existingSelector = {
      rule: {
        id: "id1",
        tagName: "p",
        type: "rule"
      },
      type: "ruleSet"
    };
    var result = "p#id1.refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });

  test("for universal selector", function() {
    var existingSelector = {
      rule: {
        classNames: ["class"],
        type: "rule",
        rule: {
          tagName: "*",
          type: "rule"
        }
      },
      type: "ruleSet"
    };
    var result = ".refactoring-" + GUID;

    strictEqual(RefactorUndoingStyle._newSelector(existingSelector).selectorText, result);
  });



module("_createRule should create correct style declaration", {
  beforeEach: function() {
    Utils.guid = function() { return GUID; };
  }
});
  test("for a normal property", function() {
    var overriddenStyle = {
      ruleWrapper: {
        declarations: {
          "border-bottom-style": {
            value: "solid",
            isImportant: false
          }
        },
        rule: undefined,
        selector: {
          rule: {
            tagName: "p",
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: "p",
        specificity: [0,0,0,1],
        parentRule: undefined,
        index: 0
      },
      declaration: {
        property: "border-bottom-style",
        value: "solid",
        isImportant: false
      }
    };
    var result = ".refactoring-" + GUID + "{ border-bottom-style: solid; }";

    strictEqual(RefactorUndoingStyle._createRule(overriddenStyle).cssText, result);
  });

  test("for an important property", function() {
    var overriddenStyle = {
      ruleWrapper: {
        declarations: {
          "border-bottom-style": {
            value: "solid",
            isImportant: true
          }
        },
        rule: undefined,
        selector: {
          rule: {
            tagName: "p",
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: "p",
        specificity: [0,0,0,1],
        parentRule: undefined,
        index: 0
      },
      declaration: {
        property: "border-bottom-style",
        value: "solid",
        isImportant: true
      }
    };
    var result = ".refactoring-" + GUID + "{ border-bottom-style: solid !important; }";

    strictEqual(RefactorUndoingStyle._createRule(overriddenStyle).cssText, result);
  });



module("");
  test("Dummy test, needed to set QUnit stylesheet", function() {
    $('head').append('<link rel="stylesheet" href="vendor/qunit.css" />');
    ok(true);
  });

function setup(style, enclosedRulesGroup) {
  $('style').html('');
  $('style').html(style);
  enclosedRulesGroup[0].smell.reset.ruleWrapper.rule = document.styleSheets[0].cssRules[0];
  enclosedRulesGroup[0].smell.enclosed[0].ruleWrapper.rule = document.styleSheets[0].cssRules[1];
}

function setupMultipleReset(enclosedRulesGroup) {
  $('style').html('');
  $('style').html(MULTIPLE_RESET_STYLE);
  enclosedRulesGroup[0].smell.reset.ruleWrapper.rule = document.styleSheets[0].cssRules[0];
  enclosedRulesGroup[1].smell.reset.ruleWrapper.rule = document.styleSheets[0].cssRules[1];
  enclosedRulesGroup[0].smell.enclosed[0].ruleWrapper.rule = document.styleSheets[0].cssRules[2];
  enclosedRulesGroup[1].smell.enclosed[0].ruleWrapper.rule = document.styleSheets[0].cssRules[2];
}
