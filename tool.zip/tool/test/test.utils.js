/*global module, test, strictEqual*/
/*global Utils*/

module("'compareSpecificity' should correctly compare two specificity matrices");
  test("element should have same specificity as element", function() {
    var elementSpecificity = [0,0,0,1];

    strictEqual(Utils.compareSpecificity(elementSpecificity, elementSpecificity), 0);
  });

  test("class should have higher specificity than element", function() {
    var classSpecificity = [0,0,1,0];
    var elementSpecificity = [0,0,0,1];

    strictEqual(Utils.compareSpecificity(classSpecificity, elementSpecificity), 1);
  });

  test("element should have lower specificity than class", function() {
    var elementSpecificity = [0,0,0,1];
    var classSpecificity = [0,0,1,0];

    strictEqual(Utils.compareSpecificity(elementSpecificity, classSpecificity), -1);
  });

  test("id should have higher specificity than 10 classes", function() {
    var idSpecificity = [0,1,0,0];
    var classesSpecificity = [0,0,10,0];

    strictEqual(Utils.compareSpecificity(idSpecificity, classesSpecificity), 1);
  });
