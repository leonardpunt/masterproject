/*global module, test, deepEqual, ok, strictEqual*/
/*global CSSParserExtension, Utils*/

var elementStyle = "p {"+
  "color: red;"+
  "margin-left: 50px;"+
"}";
var classStyle = ".class {"+
  "font-size: 50px;"+
  "color: green;"+
"}";
var idStyle = "#zero {"+
  "margin-right: 0;"+
"}";



module("getRules should correctly fill 'selector'");
  test("for elements", function() {
    var result = {
      rule: {
        tagName: "p",
        type: "rule"
      },
      type: "ruleSet"
    };

    var styleSheets = setStyle(elementStyle);
    deepEqual(CSSParserExtension.getRules(styleSheets)[0].selector, result);
  });

  test("for classes", function() {
    var result = {
      rule: {
        classNames: [ "class" ],
        type: "rule"
      },
      type: "ruleSet"
    };

    var styleSheets = setStyle(classStyle);
    deepEqual(CSSParserExtension.getRules(styleSheets)[0].selector, result);
  });

  test("for ids", function() {
    var result = {
      rule: {
        id: "zero",
        type: "rule"
      },
      type: "ruleSet"
    };

    var styleSheets = setStyle(idStyle);
    deepEqual(CSSParserExtension.getRules(styleSheets)[0].selector, result);
  });

  test("a grouping selector", function() {
    var style =
    "p, div {"+
      "color: red;"+
    "}";
    var result0 = {
      rule: {
        tagName: "p",
        type: "rule"
      },
      type: "ruleSet"
    };
    var result1 = {
      rule: {
        tagName: "div",
        type: "rule"
      },
      type: "ruleSet"
    };

    var styleSheets = setStyle(style);
    deepEqual(CSSParserExtension.getRules(styleSheets)[0].selector, result0);
    deepEqual(CSSParserExtension.getRules(styleSheets)[1].selector, result1);
  });



module("getRules should correctly fill 'selectorText'");
  test("for elements", function() {
    var result = "p";

    var styleSheets = setStyle(elementStyle);
    strictEqual(CSSParserExtension.getRules(styleSheets)[0].selectorText, result);
  });

  test("for classes", function() {
    var result = ".class";

    var styleSheets = setStyle(classStyle);
    strictEqual(CSSParserExtension.getRules(styleSheets)[0].selectorText, result);
  });

  test("for ids", function() {
    var result = "#zero";

    var styleSheets = setStyle(idStyle);
    strictEqual(CSSParserExtension.getRules(styleSheets)[0].selectorText, result);
  });

  test("a grouping selector", function() {
    var style =
    "p, div {"+
      "color: red;"+
    "}";
    var result0 = "p";
    var result1 = "div";

    var styleSheets = setStyle(style);
    strictEqual(CSSParserExtension.getRules(styleSheets)[0].selectorText, result0);
    strictEqual(CSSParserExtension.getRules(styleSheets)[1].selectorText, result1);
  });



module("getRules should correctly fill 'specificity'");
  test("for elements", function() {
    var result = [0,0,0,1];

    var styleSheets = setStyle(elementStyle);
    deepEqual(CSSParserExtension.getRules(styleSheets)[0].specificity, result);
  });

  test("for classes", function() {
    var result = [0,0,1,0];

    var styleSheets = setStyle(classStyle);
    deepEqual(CSSParserExtension.getRules(styleSheets)[0].specificity, result);
  });

  test("for ids", function() {
    var result = [0,1,0,0];

    var styleSheets = setStyle(idStyle);
    deepEqual(CSSParserExtension.getRules(styleSheets)[0].specificity, result);
  });

  test("a grouping selector", function() {
    var style =
    "p, div {"+
      "color: red;"+
    "}";
    var result0 = [0,0,0,1];
    var result1 = [0,0,0,1];

    var styleSheets = setStyle(style);
    deepEqual(CSSParserExtension.getRules(styleSheets)[0].specificity, result0);
    deepEqual(CSSParserExtension.getRules(styleSheets)[1].specificity, result1);
  });

  test("an id should have a higher specificity than 11 classes", function() {
    var style =
    "#id {"+
      "color: red;"+
    "}"+
    ".class1.class2.class3.class4.class5.class6.class7.class8.class9.class10.class11 {"+
      "color: red;"+
    "}";

    var styleSheets = setStyle(style);
    strictEqual(Utils.compareSpecificity(CSSParserExtension.getRules(styleSheets)[0].specificity, CSSParserExtension.getRules(styleSheets)[1].specificity), 1);
  });



module("getRules should not alter 'rule.selectorText'");
  test("for elements", function() {
    var result = "p";

    var styleSheets = setStyle(elementStyle);
    strictEqual(CSSParserExtension.getRules(styleSheets)[0].rule.selectorText, result);
  });

  test("for classes", function() {
    var result = ".class";

    var styleSheets = setStyle(classStyle);
    strictEqual(CSSParserExtension.getRules(styleSheets)[0].rule.selectorText, result);
  });

  test("for ids", function() {
    var result = "#zero";

    var styleSheets = setStyle(idStyle);
    strictEqual(CSSParserExtension.getRules(styleSheets)[0].rule.selectorText, result);
  });

  test("a grouping selector", function() {
    var style =
    "p, div {"+
      "color: red;"+
    "}";
    var result = "p, div";

    var styleSheets = setStyle(style);
    strictEqual(CSSParserExtension.getRules(styleSheets)[0].rule.selectorText, result);
    strictEqual(CSSParserExtension.getRules(styleSheets)[1].rule.selectorText, result);
  });



module("getRules should correctly fill 'declarations'");
  test("for elements", function() {
    var result = {
      "color": { value: "red", isImportant: false },
      "margin-left": { value: "50px", isImportant: false }
    };

    var styleSheets = setStyle(elementStyle);
    deepEqual(CSSParserExtension.getRules(styleSheets)[0].declarations, result);
  });

  test("for classes", function() {
    var result = {
      "font-size": { value: "50px", isImportant: false },
      "color": { value: "green", isImportant: false }
    };

    var styleSheets = setStyle(classStyle);
    deepEqual(CSSParserExtension.getRules(styleSheets)[0].declarations, result);
  });

  test("for ids", function() {
    var result = {
      "margin-right": { value: "0px", isImportant: false }
    };

    var styleSheets = setStyle(idStyle);
    deepEqual(CSSParserExtension.getRules(styleSheets)[0].declarations, result);
  });

  test("a shorthand property", function() {
    var style = "p {"+
      "border-bottom: 1px solid red;"+
    "}";
    var result = {
      "border-bottom-width": { value: "1px", isImportant: false },
      "border-bottom-style": { value: "solid", isImportant: false },
      "border-bottom-color": { value:"red", isImportant: false },
    };

    var styleSheets = setStyle(style);
    deepEqual(CSSParserExtension.getRules(styleSheets)[0].declarations, result);
  });

  test("an '!important' property", function() {
    var style = "p {"+
      "color: red !important;"+
    "}";
    var result =  {
      "color": { value: "red", isImportant: true },
    };

    var styleSheets = setStyle(style);
    deepEqual(CSSParserExtension.getRules(styleSheets)[0].declarations, result);
  });

  test("a grouping selector", function() {
    var style =
    "p, div {"+
      "color: red;"+
    "}";
    var result = {
      "color": { value: "red", isImportant: false }
    };

    var styleSheets = setStyle(style);
    deepEqual(CSSParserExtension.getRules(styleSheets)[0].declarations, result);
    deepEqual(CSSParserExtension.getRules(styleSheets)[1].declarations, result);
  });

  test("a '@media' rule, i.e. it should be ignored", function() {
    var style = "@media screen and (max-width: 800px) {"+
      "p {"+
        "color: red;"+
        "margin-left: 50px;"+
      "}"+
      ".class {"+
        "font-size: 50px;"+
        "color: green;"+
      "}"+
    "}";
    var styleSheets = setStyle(style);

    strictEqual(CSSParserExtension.getRules(styleSheets).length, 0);
  });



module("getRules should not alter field 'parentStyleSheet'");
  test("for any rule", function() {
    var styleSheets = setStyle(elementStyle);
    ok("parentStyleSheet" in CSSParserExtension.getRules(styleSheets)[0].rule);
  });



module("getRules should not alter field 'parentRule'");
  test("for any rule", function() {
    var styleSheets = setStyle(elementStyle);
    ok("parentRule" in CSSParserExtension.getRules(styleSheets)[0].rule);
  });



module("");
  test("Dummy test, needed to set QUnit stylesheet", function() {
    $('head').append('<link rel="stylesheet" href="vendor/qunit.css" />');
    ok(true);
  });

function setStyle(style) {
  $('style').html(style);
  return document.styleSheets;
}
