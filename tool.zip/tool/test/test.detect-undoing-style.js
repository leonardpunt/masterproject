/*global QUnit, module, test, deepEqual, strictEqual*/
/*global UndoingStyle*/

QUnit.dump.maxDepth = 6;

var ANY_DEFAULT_STYLES = {};

test("Filter undoing style on CSS rules without undoing style should return empty list", function() {
  var definedCSSRules = [
    {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p",
      specificity: [0,0,0,1],
      declarations: {
        "color": { value: "red", isImportant: false },
        "border-bottom-width": { value: "1px", isImportant: false },
        "border-bottom-style": { value: "solid", isImportant: false },
        "border-bottom-color": { value:"red", isImportant: false },
        "margin-left": { value: "50px", isImportant: false }
      }
    }, {
      rule: undefined,
      selector: {
        rule: {
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".class",
      specificity: [0,0,1,0],
      declarations: {
        "font-size": { value: "50px", isImportant: false },
        "color": { value: "green", isImportant: false }
      }
    }
  ];
  var result = [];

  deepEqual(UndoingStyle.filterUndoingStyle(definedCSSRules, ANY_DEFAULT_STYLES), result);
});

test("Filter undoing style on CSS rules with a 'none' value that isn't overridden should return empty list", function() {
  var definedCSSRules = [
    {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p",
      specificity: [0,0,0,1],
      declarations: {
        "margin-left": { value: "50px", isImportant: false }
      }
    }, {
      rule: undefined,
      selector: {
        rule: {
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".class",
      specificity: [0,0,1,0],
      declarations: {
        "text-decoration": { value: "none", isImportant: false }
      }
    }
  ];
  var result = [];

  deepEqual(UndoingStyle.filterUndoingStyle(definedCSSRules, ANY_DEFAULT_STYLES), result);
});

test("Filter undoing style on CSS rules with a '0' value that isn't overridden should return empty list", function() {
  var definedCSSRules = [
    {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p",
      specificity: [0,0,0,1],
      declarations: {
        "margin-left": { value: "0px", isImportant: false }
      }
    }, {
      rule: undefined,
      selector: {
        rule: {
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".class",
      specificity: [0,0,1,0],
      declarations: {
        "text-decoration": { value: "underline", isImportant: false }
      }
    }
  ];
  var result = [];

  deepEqual(UndoingStyle.filterUndoingStyle(definedCSSRules, ANY_DEFAULT_STYLES), result);
});

test("Filter undoing style on CSS rules with a 'none' value that is overridden should return that declaration", function() {
  var definedCSSRules = [
    {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p",
      specificity: [0,0,0,1],
      declarations: {
        "text-decoration": { value: "none", isImportant: false }
      }
    },
    {
      rule: undefined,
      selector: {
        rule: {
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".class",
      specificity: [0,0,1,0],
      declarations: {
        "text-decoration": { value: "underline", isImportant: false }
      }
    }, {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p.class",
      specificity: [0,0,1,1],
      declarations: {
        "text-decoration": { value: "none", isImportant: false }
      }
    }
  ];
  var defaultStyles = {
    "text-decoration": "overline"
  };
  var result = [{
    isRefactorable: true,
    initial: {
      declaration: {
        property: "text-decoration",
        value: "none",
        isImportant: false
      },
      ruleWrapper: {
        rule: undefined,
        declarations: {
          "text-decoration": {
            value: "none",
            isImportant: false
          }
        },
        selector: {
          rule: {
            tagName: "p",
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: "p",
        specificity: [0,0,0,1]
      }
    },
    enclosed: [{
      declaration: {
        property: "text-decoration",
        value: "underline",
        isImportant: false
      },
      ruleWrapper: {
        rule: undefined,
        declarations: {
          "text-decoration": {
            value: "underline",
            isImportant: false
          }
        },
        selector: {
          rule: {
            classNames: [ "class" ],
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: ".class",
        specificity: [0,0,1,0]
      }
    }],
    reset: {
      declaration: {
        property: "text-decoration",
        value: "none",
        isImportant: false
      },
      ruleWrapper: {
        rule: undefined,
        declarations: {
          "text-decoration": {
            value: "none",
            isImportant: false
          }
        },
        selector: {
          rule: {
            tagName: "p",
            classNames: [ "class" ],
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: "p.class",
        specificity: [0,0,1,1]
      }
    }
  }];

  deepEqual(UndoingStyle.filterUndoingStyle(definedCSSRules, defaultStyles), result);
});

test("Filter undoing style on CSS rules with a 'none' value that is overridden should not return that declaration, if it contains an implicit style", function() {
  var definedCSSRules = [
    {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p",
      specificity: [0,0,0,1],
      declarations: {
        "text-decoration": { value: "underline", isImportant: false }
      }
    }, {
      rule: undefined,
      selector: {
        rule: {
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".class",
      specificity: [0,0,1,0],
      declarations: {
        "text-decoration": { value: "none", isImportant: false }
      }
    }
  ];
  var defaultStyles = {
    "text-decoration": "overline"
  };
  var result = [];

  deepEqual(UndoingStyle.filterUndoingStyle(definedCSSRules, defaultStyles), result);
});

test("Filter undoing style on CSS rules with a '0' value that is overridden should return that declaration", function() {
  var definedCSSRules = [
    {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p",
      specificity: [0,0,0,1],
      declarations: {
        "margin-left": { value: "0px", isImportant: false }
      }
    },
    {
      rule: undefined,
      selector: {
        rule: {
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".class",
      specificity: [0,0,1,0],
      declarations: {
        "margin-left": { value: "5px", isImportant: false }
      }
    }, {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p.class",
      specificity: [0,0,1,1],
      declarations: {
        "margin-left": { value: "0px", isImportant: false }
      }
    }
  ];
  var defaultStyles = {
    "margin-left": "100px"
  };
  var result = [{
    isRefactorable: true,
    initial: {
      declaration: {
        property: "margin-left",
        value: "0px",
        isImportant: false
      },
      ruleWrapper: {
        rule: undefined,
        declarations: {
          "margin-left": {
            value: "0px",
            isImportant: false
          }
        },
        selector: {
          rule: {
            tagName: "p",
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: "p",
        specificity: [0,0,0,1]
      }
    },
    enclosed: [{
      declaration: {
        property: "margin-left",
        value: "5px",
        isImportant: false
      },
      ruleWrapper: {
        rule: undefined,
        declarations: {
          "margin-left": {
            value: "5px",
            isImportant: false
          }
        },
        selector: {
          rule: {
            classNames: [ "class" ],
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: ".class",
        specificity: [0,0,1,0]
      }
    }],
    reset: {
      declaration: {
        property: "margin-left",
        value: "0px",
        isImportant: false
      },
      ruleWrapper: {
        rule: undefined,
        declarations: {
          "margin-left": {
            value: "0px",
            isImportant: false
          }
        },
        selector: {
          rule: {
            tagName: "p",
            classNames: [ "class" ],
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: "p.class",
        specificity: [0,0,1,1]
      }
    }
  }];

  deepEqual(UndoingStyle.filterUndoingStyle(definedCSSRules, defaultStyles), result);
});

test("Filter undoing style on CSS rules with a '0' value that is overridden should not return that declaration, if it contains an implicit style", function() {
  var definedCSSRules = [
    {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p",
      specificity: [0,0,0,1],
      declarations: {
        "margin-left": { value: "5px", isImportant: false }
      }
    }, {
      rule: undefined,
      selector: {
        rule: {
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".class",
      specificity: [0,0,1,0],
      declarations: {
        "margin-left": { value: "0px", isImportant: false }
      }
    }, {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p.class",
      specificity: [0,0,1,1],
      declarations: {
        "margin-left": { value: "10px", isImportant: false }
      }
    }
  ];
  var defaultStyles = {
    "margin-left": "100px"
  };
  var result = [];

  deepEqual(UndoingStyle.filterUndoingStyle(definedCSSRules, defaultStyles), result);
});

test("Filter undoing style on CSS rules with '0' value that overrides a '0' value should return that declaration", function() {
  var definedCSSRules = [
    {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p",
      specificity: [0,0,0,1],
      declarations: {
        "margin-left": { value: "0px", isImportant: false }
      }
    }, {
      rule: undefined,
      selector: {
        rule: {
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".class",
      specificity: [0,0,1,0],
      declarations: {
        "margin-left": { value: "0px", isImportant: false }
      }
    }, {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p.class",
      specificity: [0,0,1,1],
      declarations: {
        "margin-left": { value: "0px", isImportant: false }
      }
    }
  ];
  var defaultStyles = {
    "margin-left": "100px"
  };
  var result = [{
    isRefactorable: true,
    initial: {
      declaration: {
        property: "margin-left",
        value: "0px",
        isImportant: false
      },
      ruleWrapper: {
        rule: undefined,
        declarations: {
          "margin-left": {
            value: "0px",
            isImportant: false
          }
        },
        selector: {
          rule: {
            tagName: "p",
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: "p",
        specificity: [0,0,0,1]
      }
    },
    enclosed: [{
      declaration: {
        property: "margin-left",
        value: "0px",
        isImportant: false
      },
      ruleWrapper: {
        rule: undefined,
        declarations: {
          "margin-left": {
            value: "0px",
            isImportant: false
          }
        },
        selector: {
          rule: {
            classNames: [ "class" ],
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: ".class",
        specificity: [0,0,1,0]
      }
    }],
    reset: {
      declaration: {
        property: "margin-left",
        value: "0px",
        isImportant: false
      },
      ruleWrapper: {
        rule: undefined,
        declarations: {
          "margin-left": {
            value: "0px",
            isImportant: false
          }
        },
        selector: {
          rule: {
            tagName: "p",
            classNames: [ "class" ],
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: "p.class",
        specificity: [0,0,1,1]
      }
    }
  }];

  deepEqual(UndoingStyle.filterUndoingStyle(definedCSSRules, defaultStyles), result);
});

test("Filter undoing style on CSS rules with 'none' value which selector has lower specificity, but has !important, should return that declaration", function() {
  var definedCSSRules = [
  {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p",
      specificity: [0,0,0,1],
      declarations: {
        "text-decoration": { value: "none", isImportant: false }
      }
    },
    {
      rule: undefined,
      selector: {
        rule: {
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".class",
      specificity: [0,0,1,0],
      declarations: {
        "text-decoration": { value: "none", isImportant: true }
      }
    }, {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p.class",
      specificity: [0,0,1,1],
      declarations: {
        "text-decoration": { value: "underline", isImportant: false }
      }
    }
  ];
  var defaultStyles = {
    "text-decoration": "overline"
  };
  var result = [{
    isRefactorable: true,
    initial: {
      declaration: {
        property: "text-decoration",
        value: "none",
        isImportant: false
      },
      ruleWrapper: {
        rule: undefined,
        declarations: {
          "text-decoration": {
            value: "none",
            isImportant: false
          }
        },
        selector: {
          rule: {
            tagName: "p",
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: "p",
        specificity: [0,0,0,1]
      }
    },
    enclosed: [{
      declaration: {
        property: "text-decoration",
        value: "underline",
        isImportant: false
      },
      ruleWrapper: {
        rule: undefined,
        declarations: {
          "text-decoration": {
            value: "underline",
            isImportant: false
          }
        },
        selector: {
          rule: {
            tagName: "p",
            classNames: [ "class" ],
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: "p.class",
        specificity: [0,0,1,1]
      }
    }],
    reset: {
      declaration: {
        property: "text-decoration",
        value: "none",
        isImportant: true
      },
      ruleWrapper: {
        rule: undefined,
        declarations: {
          "text-decoration": {
            value: "none",
            isImportant: true
          }
        },
        selector: {
          rule: {
            classNames: [ "class" ],
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: ".class",
        specificity: [0,0,1,0]
      }
    }
  }];

  deepEqual(UndoingStyle.filterUndoingStyle(definedCSSRules, defaultStyles), result);
});

test("Filter undoing style on CSS rules with '0' value which selector has lower specificity, but has !important, should return that declaration", function() {
  var definedCSSRules = [
    {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p",
      specificity: [0,0,0,1],
      declarations: {
        "margin-left": { value: "0px", isImportant: false }
      }
    },
    {
      rule: undefined,
      selector: {
        rule: {
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".class",
      specificity: [0,0,1,0],
      declarations: {
        "margin-left": { value: "0px", isImportant: true }
      }
    }, {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p.class",
      specificity: [0,0,1,1],
      declarations: {
        "margin-left": { value: "10px", isImportant: false }
      }
    }
  ];
  var defaultStyles = {
    "margin-left": "100px"
  };
  var result = [{
    isRefactorable: true,
    initial: {
      declaration: {
        property: "margin-left",
        value: "0px",
        isImportant: false
      },
      ruleWrapper: {
        rule: undefined,
        declarations: {
          "margin-left": {
            value: "0px",
            isImportant: false
          }
        },
        selector: {
          rule: {
            tagName: "p",
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: "p",
        specificity: [0,0,0,1]
      }
    },
    enclosed: [{
      declaration: {
        property: "margin-left",
        value: "10px",
        isImportant: false
      },
      ruleWrapper: {
        rule: undefined,
        declarations: {
          "margin-left": {
            value: "10px",
            isImportant: false
          }
        },
        selector: {
          rule: {
            tagName: "p",
            classNames: [ "class" ],
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: "p.class",
        specificity: [0,0,1,1]
      }
    }],
    reset: {
      declaration: {
        property: "margin-left",
        value: "0px",
        isImportant: true
      },
      ruleWrapper: {
        rule: undefined,
        declarations: {
          "margin-left": {
            value: "0px",
            isImportant: true
          }
        },
        selector: {
          rule: {
            classNames: [ "class" ],
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: ".class",
        specificity: [0,0,1,0]
      }
    }
  }];

  deepEqual(UndoingStyle.filterUndoingStyle(definedCSSRules, defaultStyles), result);
});

test("Filter undoing style on CSS rules with '0' value which selector pseudo class 'first-child' should not return that declaration", function() {
  var definedCSSRules = [
    {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p",
      specificity: [0,0,0,1],
      declarations: {
        "margin-left": { value: "0px", isImportant: false }
      }
    }, {
      rule: undefined,
      selector: {
        rule: {
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".class",
      specificity: [0,0,1,0],
      declarations: {
        "margin-left": { value: "10px", isImportant: false }
      }
    }, {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          pseudos: [ { name: "first-child" }],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p:first-child",
      specificity: [0,0,1,1],
      declarations: {
        "margin-left": { value: "0px", isImportant: false }
      }
    }
  ];
  var defaultStyles = {
    "margin-left": "100px"
  };
  var result = [];

  deepEqual(UndoingStyle.filterUndoingStyle(definedCSSRules, defaultStyles), result);
});

test("Filter undoing style on CSS rules with '0' value which selector pseudo class 'last-child' should not return that declaration", function() {
  var definedCSSRules = [
    {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p",
      specificity: [0,0,0,1],
      declarations: {
        "margin-left": { value: "0px", isImportant: false }
      }
    }, {
      rule: undefined,
      selector: {
        rule: {
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".class",
      specificity: [0,0,1,0],
      declarations: {
        "margin-left": { value: "10px", isImportant: false }
      }
    }, {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          pseudos: [ { name: "last-child" }],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p:last-child",
      specificity: [0,0,1,1],
      declarations: {
        "margin-left": { value: "0px", isImportant: false }
      }
    }
  ];
  var defaultStyles = {
    "margin-left": "100px"
  };
  var result = [];

  deepEqual(UndoingStyle.filterUndoingStyle(definedCSSRules, defaultStyles), result);
});

test("Filter undoing style on CSS rules with '0' value which selector pseudo class 'nth-child' should not return that declaration", function() {
  var definedCSSRules = [
    {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p",
      specificity: [0,0,0,1],
      declarations: {
        "margin-left": { value: "0px", isImportant: false }
      }
    }, {
      rule: undefined,
      selector: {
        rule: {
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".class",
      specificity: [0,0,1,0],
      declarations: {
        "margin-left": { value: "10px", isImportant: false }
      }
    }, {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          pseudos: [ { name: "nth-child" }],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p:nth-child",
      specificity: [0,0,1,1],
      declarations: {
        "margin-left": { value: "0px", isImportant: false }
      }
    }
  ];
  var defaultStyles = {
    "margin-left": "100px"
  };
  var result = [];

  deepEqual(UndoingStyle.filterUndoingStyle(definedCSSRules, defaultStyles), result);
});

test("Filter undoing style on CSS rules with '0' value which selector pseudo class 'nth-last-child' should not return that declaration", function() {
  var definedCSSRules = [
    {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p",
      specificity: [0,0,0,1],
      declarations: {
        "margin-left": { value: "0px", isImportant: false }
      }
    },
    {
      rule: undefined,
      selector: {
        rule: {
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".class",
      specificity: [0,0,1,0],
      declarations: {
        "margin-left": { value: "10px", isImportant: false }
      }
    }, {
      rule: undefined,
      selector: {
        rule: {
          tagName: "p",
          pseudos: [ { name: "nth-last-child" }],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p:nth-last-child",
      specificity: [0,0,1,1],
      declarations: {
        "margin-left": { value: "0px", isImportant: false }
      }
    }
  ];
  var defaultStyles = {
    "margin-left": "100px"
  };
  var result = [];

  deepEqual(UndoingStyle.filterUndoingStyle(definedCSSRules, defaultStyles), result);
});



module("_compareCascadingOrder should respond correctly");
  test("for styles with the different specificity", function() {
    var thisRule = {
      declaration: {
        property: "margin-left",
        value: "0px",
        isImportant: false
      },
      rule: {
        rule: undefined,
        declarations: {
          "margin-left": {
            value: "0px",
            isImportant: false
          }
        },
        selector: {
          rule: {
            classNames: [ "thisRule" ],
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: ".thisRule",
        specificity: [0,0,1,0]
      }
    };
    var anotherRule = {
      declaration: {
        property: "margin-left",
        value: "10px",
        isImportant: false
      },
      rule: {
        rule: undefined,
        declarations: {
          "margin-left": {
            value: "10px",
            isImportant: false
          }
        },
        selector: {
          tagName: "p",
          type: "ruleSet"
        },
        selectorText: "p",
        specificity: [0,0,0,1]
      }
    };

    strictEqual(UndoingStyle._compareCascadingOrder(thisRule, anotherRule), 1);
    strictEqual(UndoingStyle._compareCascadingOrder(anotherRule, thisRule), -1);
  });

  test("for styles with the !important", function() {
    var thisRule = {
      declaration: {
        property: "margin-left",
        value: "0px",
        isImportant: false
      },
      rule: {
        rule: undefined,
        declarations: {
          "margin-left": {
            value: "0px",
            isImportant: false
          }
        },
        selector: {
          rule: {
            classNames: [ "thisRule" ],
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: ".thisRule",
        specificity: [0,0,1,0]
      }
    };
    var anotherRule = {
      declaration: {
        property: "margin-left",
        value: "10px",
        isImportant: true
      },
      rule: {
        rule: undefined,
        declarations: {
          "margin-left": {
            value: "10px",
            isImportant: false
          }
        },
        selector: {
          tagName: "p",
          type: "ruleSet"
        },
        selectorText: "p",
        specificity: [0,0,0,1]
      }
    };

    strictEqual(UndoingStyle._compareCascadingOrder(thisRule, anotherRule), -1);
    strictEqual(UndoingStyle._compareCascadingOrder(anotherRule, thisRule), 1);
  });

  test("for styles with the same specificity that are defined in the same style sheet", function() {
    var style = ".thisRule {"+
      "margin-left: 0px;"+
    "}"+
    ".anotherRule {"+
      "margin-left: 10px;"+
    "}";
    var thisRule = {
      declaration: {
        property: "margin-left",
        value: "0px",
        isImportant: false
      },
      rule: {
        rule: undefined,
        declarations: {
          "margin-left": {
            value: "0px",
            isImportant: false
          }
        },
        selector: {
          rule: {
            classNames: [ "thisRule" ],
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: ".thisRule",
        specificity: [0,0,1,0]
      }
    };
    var anotherRule = {
      declaration: {
        property: "margin-left",
        value: "10px",
        isImportant: false
      },
      rule: {
        rule: undefined,
        declarations: {
          "margin-left": {
            value: "10px",
            isImportant: false
          }
        },
        selector: {
          rule: {
            classNames: [ "anotherRule" ],
            type: "rule"
          },
          type: "ruleSet"
        },
        selectorText: ".anotherRule",
        specificity: [0,0,1,0]
      }
    };
    setup(style, [thisRule, anotherRule]);

    strictEqual(UndoingStyle._compareCascadingOrder(thisRule, anotherRule, document.styleSheets), -1);
    strictEqual(UndoingStyle._compareCascadingOrder(anotherRule, thisRule, document.styleSheets), 1);
  });

module("_isRuleListedLater should respond correctly");
  test("for CSSStyleRules", function() {
    var style = ".thisrule {"+
      "margin-left: 0px;"+
    "}"+
    ".anotherrule {"+
      "margin-left: 10px;"+
    "}";
    setup(style, []);

    var styleSheet = document.styleSheets[1];
    var thisRule = styleSheet.cssRules[0];
    var anotherRule = styleSheet.cssRules[1];

    strictEqual(UndoingStyle._isRuleListedLater(styleSheet, thisRule, anotherRule, ".thisrule", ".anotherrule"), false);
    strictEqual(UndoingStyle._isRuleListedLater(styleSheet, anotherRule, thisRule, ".anotherrule", ".thisrule"), true);
  });

  test("for CSSMediaRules", function() {
    var style = "@media screen and (max-width: 47.5em) {"+
    ".thisrule {"+
      "margin-left: 0px;"+
    "}"+
    "}"+
    "@media screen and (min-width: 47.5em) {"+
    ".anotherrule {"+
      "margin-left: 10px;"+
    "}"+
    "}";
    setup(style, []);

    var styleSheet = document.styleSheets[1];
    var thisRule = styleSheet.cssRules[0].cssRules[0];
    var anotherRule = styleSheet.cssRules[1].cssRules[0];

    strictEqual(UndoingStyle._isRuleListedLater(styleSheet, thisRule, anotherRule, ".thisrule", ".anotherrule"), undefined);
    strictEqual(UndoingStyle._isRuleListedLater(styleSheet, anotherRule, thisRule, ".anotherrule", ".thisrule"), undefined);
  });

  test("for grouped Rules", function() {
    var style = ".thisrule, .anotherrule {"+
      "margin-left: 0px;"+
    "}";
    setup(style, []);

    var styleSheet = document.styleSheets[1];
    var thisRule = styleSheet.cssRules[0];
    var anotherRule = styleSheet.cssRules[0];

    strictEqual(UndoingStyle._isRuleListedLater(styleSheet, thisRule, anotherRule, ".thisrule", ".anotherrule"), false);
    strictEqual(UndoingStyle._isRuleListedLater(styleSheet, anotherRule, thisRule, ".anotherrule", ".thisrule"), true);
  });

module("_detectABA should respond correctly");
  test("for A-A", function() {
    var overridingDeclaration = {
      property: "color",
      rules: [
        { declaration: { property: "color", value: "red", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "red", isImportant: false }, rule: undefined }
      ]
    };

    var result = [{
      lowestA: 1,
      highestA: 0
    }];

    deepEqual(UndoingStyle._detectABA(overridingDeclaration), result);
  });

  test("for A-B-A", function() {
    var overridingDeclaration = {
      property: "color",
      rules: [
        { declaration: { property: "color", value: "red", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "blue", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "red", isImportant: false }, rule: undefined }
      ]
    };

    var result = [{
      lowestA: 2,
      highestA: 0
    }];

    deepEqual(UndoingStyle._detectABA(overridingDeclaration), result);
  });

  test("for A-B-A-C", function() {
    var overridingDeclaration = {
      property: "color",
      rules: [
        { declaration: { property: "color", value: "green", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "red", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "blue", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "red", isImportant: false }, rule: undefined }
      ]
    };

    var result = [{
      lowestA: 3,
      highestA: 1
    }];

    deepEqual(UndoingStyle._detectABA(overridingDeclaration), result);
  });

  test("for A-B-C-D-B", function() {
    var overridingDeclaration = {
      property: "color",
      rules: [
        { declaration: { property: "color", value: "red", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "green", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "blue", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "red", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "rgb(0,0,0)", isImportant: false }, rule: undefined }
      ]
    };

    var result = [{
      lowestA: 3,
      highestA: 0
    }];

    deepEqual(UndoingStyle._detectABA(overridingDeclaration), result);
  });

  test("for A-B-A-B", function() {
    var overridingDeclaration = {
      property: "color",
      rules: [
        { declaration: { property: "color", value: "red", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "green", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "red", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "green", isImportant: false }, rule: undefined }
      ]
    };

    var result = [{
      lowestA: 2,
      highestA: 0
    }, {
      lowestA: 3,
      highestA: 1
    }];

    deepEqual(UndoingStyle._detectABA(overridingDeclaration), result);
  });

  test("for A-B-A-C-A", function() {
    var overridingDeclaration = {
      property: "color",
      rules: [
        { declaration: { property: "color", value: "red", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "green", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "red", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "blue", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "red", isImportant: false }, rule: undefined }
      ]
    };

    var result = [{
      lowestA: 4,
      highestA: 0
    }];

    deepEqual(UndoingStyle._detectABA(overridingDeclaration), result);
  });

  test("for A-B-A-B-A", function() {
    var overridingDeclaration = {
      property: "color",
      rules: [
        { declaration: { property: "color", value: "red", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "green", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "red", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "green", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "red", isImportant: false }, rule: undefined }
      ]
    };

    /* We expect only one result, we do not care about the inner B-A-B pattern, since for this
       specific HTML node, the whole B-A-B pattern will be removed by refactoring A-B-A-B-A.*/
    var result = [{
      lowestA: 4,
      highestA: 0
    }];

    deepEqual(UndoingStyle._detectABA(overridingDeclaration), result);
  });

  test("for A-B-A-B-A-B", function() {
    var overridingDeclaration = {
      property: "color",
      rules: [
        { declaration: { property: "color", value: "red", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "green", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "red", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "green", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "red", isImportant: false }, rule: undefined },
        { declaration: { property: "color", value: "green", isImportant: false }, rule: undefined }
      ]
    };

    var result = [{
      lowestA: 4,
      highestA: 0
    }, {
      lowestA: 5,
      highestA: 1
    }];

    deepEqual(UndoingStyle._detectABA(overridingDeclaration), result);
  });

function setup(style, rules) {
  $('style').html(style);
  rules.forEach(function(rule, i) {
    rule.rule.rule = document.styleSheets[1].cssRules[i];
  });
}
