/*global test, deepEqual, addGuidToNodes*/
/*global CSSParserExtension, Utils*/

var CSS_RULES = [
  {
    id: 1,
    groupId: 11,
    rule: {
      selectorText: "p",
      parentStyleSheet: undefined
    },
    selector: {
      rule: {
        tagName: "p",
        type: "rule"
      },
      type: "ruleSet"
    },
    selectorText: "p",
    specificity: [0,0,0,1],
    declarations: {
      "color": { value: "red", isImportant: false },
      "border-bottom-width": { value: "1px", isImportant: false },
      "border-bottom-style": { value: "solid", isImportant: false },
      "border-bottom-color": { value:"red", isImportant: false },
      "margin-left": { value: "50px", isImportant: false }
    }
  },
  {
    id: 2,
    groupId: 12,
    rule: {
      selectorText: ".class",
      parentStyleSheet: undefined
    },
    selector: {
      rule: {
        classNames: [ "class" ],
        type: "rule"
      },
      type: "ruleSet"
    },
    selectorText: ".class",
    specificity: [0,0,1,0],
    declarations: {
      "font-size": { value: "50px", isImportant: false },
      "color": { value: "green", isImportant: false }
    }
  },
  {
    id: 3,
    groupId: 13,
    rule: {
      selectorText: ".zero",
      parentStyleSheet: undefined
    },
    selector: {
      rule: {
        classNames: [ "zero" ],
        type: "rule"
      },
      type: "ruleSet"
    },
    selectorText: ".zero",
    specificity: [0,0,1,0],
    declarations: {
      "margin-right": { value: "0px", isImportant: false }
    }
  }
];

test("Retrieving the CSS declarations of an unstyled element should return an empty list", function() {
  var unstyledDiv = document.getElementById("qunit-fixture").getElementsByTagName("div")[0];
  var nodesWithRules = {};
  var result = [];

  addGuidToNodes(document.getElementById("qunit-fixture"), nodesWithRules);
  CSSParserExtension.populateNodesWithRules(document, CSS_RULES, nodesWithRules);
  deepEqual(CSSParserExtension.getDefinedRules(unstyledDiv, nodesWithRules), result);
});

test("Retrieving the CSS declarations of a styled element should return the style declared on element level", function() {
  var styledDiv = document.getElementById("qunit-fixture").getElementsByTagName("p")[0];
  var nodesWithRules = {};
  var result = [
    {
      id: 1,
      groupId: 11,
      rule: {
        selectorText: "p",
        parentStyleSheet: undefined
      },
      selector: {
        rule: {
          tagName: "p",
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p",
      specificity: [0,0,0,1],
      declarations: {
        "color": { value: "red", isImportant: false },
        "border-bottom-width": { value: "1px", isImportant: false },
        "border-bottom-style": { value: "solid", isImportant: false },
        "border-bottom-color": { value:"red", isImportant: false },
        "margin-left": { value: "50px", isImportant: false }
      }
    }
  ];

  addGuidToNodes(document.getElementById("qunit-fixture"), nodesWithRules);
  CSSParserExtension.populateNodesWithRules(document, CSS_RULES, nodesWithRules);
  deepEqual(CSSParserExtension.getDefinedRules(styledDiv, nodesWithRules), result);
});

test("Retrieving the CSS declarations of a styled element should return the style declared on element and class level", function() {
  var styledDiv = document.getElementById("qunit-fixture").getElementsByTagName("p")[1];
  var nodesWithRules = {};
  var result = [
    {
      id: 1,
      groupId: 11,
      rule: {
        selectorText: "p",
        parentStyleSheet: undefined
      },
      selector: {
        rule: {
          tagName: "p",
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p",
      specificity: [0,0,0,1],
      declarations: {
        "color": { value: "red", isImportant: false },
        "border-bottom-width": { value: "1px", isImportant: false },
        "border-bottom-style": { value: "solid", isImportant: false },
        "border-bottom-color": { value:"red", isImportant: false },
        "margin-left": { value: "50px", isImportant: false }
      }
    }, {
      id: 2,
      groupId: 12,
      rule: {
        selectorText: ".class",
        parentStyleSheet: undefined
      },
      selector: {
        rule: {
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".class",
      specificity: [0,0,1,0],
      declarations: {
        "font-size": { value: "50px", isImportant: false },
        "color": { value: "green", isImportant: false }
      }
    }
  ];

  addGuidToNodes(document.getElementById("qunit-fixture"), nodesWithRules);
  CSSParserExtension.populateNodesWithRules(document, CSS_RULES, nodesWithRules);
  deepEqual(CSSParserExtension.getDefinedRules(styledDiv, nodesWithRules), result);
});

test("Retrieving the CSS declarations of a '0' value should return the '0' appended with a unit", function() {
  var element = document.getElementById("qunit-fixture").getElementsByTagName("p")[2];
  var nodesWithRules = {};
  var result = [
    {
      id: 1,
      groupId: 11,
      rule: {
        selectorText: "p",
        parentStyleSheet: undefined
      },
      selector: {
        rule: {
          tagName: "p",
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p",
      specificity: [0,0,0,1],
      declarations: {
        "color": { value: "red", isImportant: false },
        "border-bottom-width": { value: "1px", isImportant: false },
        "border-bottom-style": { value: "solid", isImportant: false },
        "border-bottom-color": { value:"red", isImportant: false },
        "margin-left": { value: "50px", isImportant: false }
      }
    }, {
      id: 3,
      groupId: 13,
      rule: {
        selectorText: ".zero",
        parentStyleSheet: undefined
      },
      selector: {
        rule: {
          classNames: [ "zero" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".zero",
      specificity: [0,0,1,0],
      declarations: {
        "margin-right": { value: "0px", isImportant: false }
      }
    }
  ];

  addGuidToNodes(document.getElementById("qunit-fixture"), nodesWithRules);
  CSSParserExtension.populateNodesWithRules(document, CSS_RULES, nodesWithRules);
  deepEqual(CSSParserExtension.getDefinedRules(element, nodesWithRules), result);
});

test("Retrieving the CSS declarations of a styled element should include the style declared inline", function() {
  var x = 0;
  Utils.guid = function() { x=x+1; return x; };
  var element = document.getElementById("qunit-fixture").getElementsByTagName("p")[3];
  var nodesWithRules = {};
  var result = [
    {
      id: 1,
      groupId: 11,
      rule: {
        selectorText: "p",
        parentStyleSheet: undefined
      },
      selector: {
        rule: {
          tagName: "p",
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: "p",
      specificity: [0,0,0,1],
      declarations: {
        "color": { value: "red", isImportant: false },
        "border-bottom-width": { value: "1px", isImportant: false },
        "border-bottom-style": { value: "solid", isImportant: false },
        "border-bottom-color": { value:"red", isImportant: false },
        "margin-left": { value: "50px", isImportant: false }
      }
    }, {
      id: 7,
      groupId: 8,
      rule: {
        selectorText: "_inline",
      },
      selector: {
        rule: {}
      },
      selectorText: "_inline",
      specificity: [1,0,0,0],
      declarations: {
        "color": { value: "blue", isImportant: false }
      }
    }
  ];

  addGuidToNodes(document.getElementById("qunit-fixture"), nodesWithRules);
  CSSParserExtension.populateNodesWithRules(document, CSS_RULES, nodesWithRules);
  deepEqual(CSSParserExtension.getDefinedRules(element, nodesWithRules), result);
});

test("Retrieving the CSS declarations of a styled element should not include the style declared in pseudo element rules", function() {
  var element = document.getElementById("qunit-fixture").getElementsByTagName("p")[1];
  var nodesWithRules = {};
  var cssRules = [
    {
      id: 1,
      groupId: 11,
      rule: {
        selectorText: ".class",
        parentStyleSheet: undefined
      },
      selector: {
        rule: {
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".class",
      specificity: [0,0,1,0],
      declarations: {
        "color": { value: "red", isImportant: false }
      }
    }, {
      id: 2,
      groupId: 12,
      rule: {
        selectorText: ".class::after",
        parentStyleSheet: undefined
      },
      selector: {
        rule: {
          classNames: [ "class" ],
          pseudos: [ { name: "" }, { name: "after" }],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".class::after",
      specificity: [0,0,1,0],
      declarations: {
        "color": { value: "yellow", isImportant: false }
      }
    }, {
      id: 3,
      groupId: 13,
      rule: {
        selectorText: ".class::before",
        parentStyleSheet: undefined,
      },
      selector: {
        rule: {
          classNames: [ "class" ],
          pseudos: [ { name: "" }, { name: "before" }],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".class::before",
      specificity: [0,0,1,0],
      declarations: {
        "color": { value: "blue", isImportant: false }
      }
    }, {
      id: 4,
      groupId: 14,
      rule: {
        selectorText: ".class::first-letter",
        parentStyleSheet: undefined
      },
      selector: {
        rule: {
          classNames: [ "class" ],
          pseudos: [ { name: "" }, { name: "first-letter" }],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".class::first-letter",
      specificity: [0,0,1,0],
      declarations: {
        "color": { value: "green", isImportant: false }
      }
    }, {
      id: 5,
      groupId: 15,
      rule: {
        selectorText: ".class::first-line",
        parentStyleSheet: undefined
      },
      selector: {
        rule: {
          classNames: [ "class" ],
          pseudos: [ { name: "" }, { name: "first-line" }],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".class::first-line",
      specificity: [0,0,1,0],
      declarations: {
        "color": { value: "purple", isImportant: false }
      }
    }
  ];
  var result = [
    {
      id: 1,
      groupId: 11,
      rule: {
        selectorText: ".class",
        parentStyleSheet: undefined
      },
      selector: {
        rule: {
          classNames: [ "class" ],
          type: "rule"
        },
        type: "ruleSet"
      },
      selectorText: ".class",
      specificity: [0,0,1,0],
      declarations: {
        "color": { value: "red", isImportant: false }
      }
    }
  ];

  addGuidToNodes(document.getElementById("qunit-fixture"), nodesWithRules);
  CSSParserExtension.populateNodesWithRules(document, cssRules, nodesWithRules);
  deepEqual(CSSParserExtension.getDefinedRules(element, nodesWithRules), result);
});
